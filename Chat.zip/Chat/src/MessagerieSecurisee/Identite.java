package MessagerieSecurisee;

/**
 * Struct definition : Identite
 * 
 * @author OpenORB Compiler
*/
public final class Identite implements org.omg.CORBA.portable.IDLEntity
{
    /**
     * Struct member nomUtilisateur
     */
    public String nomUtilisateur;

    /**
     * Struct member mdpUtilisateur
     */
    public String mdpUtilisateur;

    /**
     * Default constructor
     */
    public Identite()
    { }

    /**
     * Constructor with fields initialization
     * @param nomUtilisateur nomUtilisateur struct member
     * @param mdpUtilisateur mdpUtilisateur struct member
     */
    public Identite(String nomUtilisateur, String mdpUtilisateur)
    {
        this.nomUtilisateur = nomUtilisateur;
        this.mdpUtilisateur = mdpUtilisateur;
    }

}
