package MessagerieSecurisee;

/**
 * Interface definition : Utilisateur
 * 
 * @author OpenORB Compiler
 */
public class _UtilisateurStub extends org.omg.CORBA.portable.ObjectImpl
        implements Utilisateur
{
    static final String[] _ids_list =
    {
        "IDL:MessagerieSecurisee/Utilisateur:1.0"
    };

    public String[] _ids()
    {
     return _ids_list;
    }

    private final static Class _opsClass = MessagerieSecurisee.UtilisateurOperations.class;

    /**
     * Operation transfererMessage
     */
    public void transfererMessage(MessagerieSecurisee.Message msg)
        throws MessagerieSecurisee.messageChiffre
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("transfererMessage",true);
                    MessagerieSecurisee.MessageHelper.write(_output,msg);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.messageChiffreHelper.id()))
                    {
                        throw MessagerieSecurisee.messageChiffreHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("transfererMessage",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    _self.transfererMessage( msg);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation transfererMessageSign
     */
    public void transfererMessageSign(MessagerieSecurisee.Message msg, short hash, MessagerieSecurisee.Certificat cert)
        throws MessagerieSecurisee.messageChiffre
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("transfererMessageSign",true);
                    MessagerieSecurisee.MessageHelper.write(_output,msg);
                    _output.write_short(hash);
                    MessagerieSecurisee.CertificatHelper.write(_output,cert);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.messageChiffreHelper.id()))
                    {
                        throw MessagerieSecurisee.messageChiffreHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("transfererMessageSign",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    _self.transfererMessageSign( msg,  hash,  cert);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demanderCertificat
     */
    public MessagerieSecurisee.Certificat demanderCertificat(String usage)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demanderCertificat",true);
                    _output.write_string(usage);
                    _input = this._invoke(_output);
                    MessagerieSecurisee.Certificat _arg_ret = MessagerieSecurisee.CertificatHelper.read(_input);
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demanderCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    return _self.demanderCertificat( usage);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation verifCertificat
     */
    public boolean verifCertificat(String usage, MessagerieSecurisee.Certificat cert)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("verifCertificat",true);
                    _output.write_string(usage);
                    MessagerieSecurisee.CertificatHelper.write(_output,cert);
                    _input = this._invoke(_output);
                    boolean _arg_ret = _input.read_boolean();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("verifCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    return _self.verifCertificat( usage,  cert);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

}
