package MessagerieSecurisee;

/**
 * Struct definition : Date
 * 
 * @author OpenORB Compiler
*/
public final class Date implements org.omg.CORBA.portable.IDLEntity
{
    /**
     * Struct member jour
     */
    public short jour;

    /**
     * Struct member mois
     */
    public short mois;

    /**
     * Struct member annee
     */
    public short annee;

    /**
     * Default constructor
     */
    public Date()
    { }

    /**
     * Constructor with fields initialization
     * @param jour jour struct member
     * @param mois mois struct member
     * @param annee annee struct member
     */
    public Date(short jour, short mois, short annee)
    {
        this.jour = jour;
        this.mois = mois;
        this.annee = annee;
    }

}
