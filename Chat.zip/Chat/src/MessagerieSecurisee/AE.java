package MessagerieSecurisee;

/**
 * Interface definition : AE
 * 
 * @author OpenORB Compiler
 */
public interface AE extends AEOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
