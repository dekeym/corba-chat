package MessagerieSecurisee;

/**
 * Interface definition : AC
 * 
 * @author OpenORB Compiler
 */
public class ACPOATie extends ACPOA
{

    //
    // Private reference to implementation object
    //
    private ACOperations _tie;

    //
    // Private reference to POA
    //
    private org.omg.PortableServer.POA _poa;

    /**
     * Constructor
     */
    public ACPOATie(ACOperations tieObject)
    {
        _tie = tieObject;
    }

    /**
     * Constructor
     */
    public ACPOATie(ACOperations tieObject, org.omg.PortableServer.POA poa)
    {
        _tie = tieObject;
        _poa = poa;
    }

    /**
     * Get the delegate
     */
    public ACOperations _delegate()
    {
        return _tie;
    }

    /**
     * Set the delegate
     */
    public void _delegate(ACOperations delegate_)
    {
        _tie = delegate_;
    }

    /**
     * _default_POA method
     */
    public org.omg.PortableServer.POA _default_POA()
    {
        if (_poa != null)
            return _poa;
        else
            return super._default_POA();
    }

    /**
     * Read accessor for identifiantAC attribute
     */
    public String identifiantAC()
    {
        return _tie.identifiantAC();
    }

    /**
     * Read accessor for certificatAC attribute
     */
    public MessagerieSecurisee.Certificat certificatAC()
    {
        return _tie.certificatAC();
    }

    /**
     * Operation creationDeCertificat
     */
    public MessagerieSecurisee.Certificat creationDeCertificat(String nomUtilisateur, MessagerieSecurisee.ListUsages usages, String CP, MessagerieSecurisee.AC Aclevel)
        throws MessagerieSecurisee.CertificatDejaCree
    {
        return _tie.creationDeCertificat( nomUtilisateur,  usages,  CP,  Aclevel);
    }

    /**
     * Operation demandeDeSuspension
     */
    public void demandeDeSuspension(String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        _tie.demandeDeSuspension( identifiantCertificatUtilisateur);
    }

    /**
     * Operation demandeDeRevocation
     */
    public void demandeDeRevocation(String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        _tie.demandeDeRevocation( identifiantCertificatUtilisateur);
    }

    /**
     * Operation demandeValidationCertificat
     */
    public boolean demandeValidationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        return _tie.demandeValidationCertificat( certificatUtilisateur);
    }

    /**
     * Operation demandeVerificationCertificat
     */
    public boolean demandeVerificationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        return _tie.demandeVerificationCertificat( certificatUtilisateur);
    }

}
