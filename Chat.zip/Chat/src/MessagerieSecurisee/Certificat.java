package MessagerieSecurisee;

/**
 * Struct definition : Certificat
 * 
 * @author OpenORB Compiler
*/
public final class Certificat implements org.omg.CORBA.portable.IDLEntity
{
    /**
     * Struct member identifiantCertificat
     */
    public String identifiantCertificat;

    /**
     * Struct member publicKey
     */
    public String publicKey;

    /**
     * Struct member ACreferant
     */
    public MessagerieSecurisee.AC ACreferant;

    /**
     * Struct member signature
     */
    public String signature;

    /**
     * Struct member dateDebut
     */
    public MessagerieSecurisee.Date dateDebut;

    /**
     * Struct member dateFin
     */
    public MessagerieSecurisee.Date dateFin;

    /**
     * Struct member usages
     */
    public MessagerieSecurisee.ListUsages usages;

    /**
     * Struct member objAV
     */
    public MessagerieSecurisee.AV objAV;

    /**
     * Struct member hash
     */
    public short hash;

    /**
     * Default constructor
     */
    public Certificat()
    { }

    /**
     * Constructor with fields initialization
     * @param identifiantCertificat identifiantCertificat struct member
     * @param publicKey publicKey struct member
     * @param ACreferant ACreferant struct member
     * @param signature signature struct member
     * @param dateDebut dateDebut struct member
     * @param dateFin dateFin struct member
     * @param usages usages struct member
     * @param objAV objAV struct member
     * @param hash hash struct member
     */
    public Certificat(String identifiantCertificat, String publicKey, MessagerieSecurisee.AC ACreferant, String signature, MessagerieSecurisee.Date dateDebut, MessagerieSecurisee.Date dateFin, MessagerieSecurisee.ListUsages usages, MessagerieSecurisee.AV objAV, short hash)
    {
        this.identifiantCertificat = identifiantCertificat;
        this.publicKey = publicKey;
        this.ACreferant = ACreferant;
        this.signature = signature;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.usages = usages;
        this.objAV = objAV;
        this.hash = hash;
    }

}
