package MessagerieSecurisee;

/**
 * Holder class for : CertificatDejaCree
 * 
 * @author OpenORB Compiler
 */
final public class CertificatDejaCreeHolder
        implements org.omg.CORBA.portable.Streamable
{
    /**
     * Internal CertificatDejaCree value
     */
    public MessagerieSecurisee.CertificatDejaCree value;

    /**
     * Default constructor
     */
    public CertificatDejaCreeHolder()
    { }

    /**
     * Constructor with value initialisation
     * @param initial the initial value
     */
    public CertificatDejaCreeHolder(MessagerieSecurisee.CertificatDejaCree initial)
    {
        value = initial;
    }

    /**
     * Read CertificatDejaCree from a marshalled stream
     * @param istream the input stream
     */
    public void _read(org.omg.CORBA.portable.InputStream istream)
    {
        value = CertificatDejaCreeHelper.read(istream);
    }

    /**
     * Write CertificatDejaCree into a marshalled stream
     * @param ostream the output stream
     */
    public void _write(org.omg.CORBA.portable.OutputStream ostream)
    {
        CertificatDejaCreeHelper.write(ostream,value);
    }

    /**
     * Return the CertificatDejaCree TypeCode
     * @return a TypeCode
     */
    public org.omg.CORBA.TypeCode _type()
    {
        return CertificatDejaCreeHelper.type();
    }

}
