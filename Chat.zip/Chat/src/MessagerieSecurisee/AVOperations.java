package MessagerieSecurisee;

/**
 * Interface definition : AV
 * 
 * @author OpenORB Compiler
 */
public interface AVOperations
{
    /**
     * Operation demandeValidationCertificat
     */
    public boolean demandeValidationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

    /**
     * Operation demandeVerificationCertificat
     */
    public boolean demandeVerificationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

}
