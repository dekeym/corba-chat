package MessagerieSecurisee;

/**
 * Interface definition : AC
 * 
 * @author OpenORB Compiler
 */
public class _ACStub extends org.omg.CORBA.portable.ObjectImpl
        implements AC
{
    static final String[] _ids_list =
    {
        "IDL:MessagerieSecurisee/AC:1.0"
    };

    public String[] _ids()
    {
     return _ids_list;
    }

    private final static Class _opsClass = MessagerieSecurisee.ACOperations.class;

    /**
     * Read accessor for identifiantAC attribute
     * @return the attribute value
     */
    public String identifiantAC()
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try {
                    org.omg.CORBA.portable.OutputStream _output = this._request("_get_identifiantAC",true);
                    _input = this._invoke(_output);
                    return _input.read_string();
                } catch (final org.omg.CORBA.portable.RemarshalException _exception) {
                    continue;
                } catch (final org.omg.CORBA.portable.ApplicationException _exception) {
                    final String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                } finally {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_identifiantAC",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.ACOperations _self = (MessagerieSecurisee.ACOperations) _so.servant;
                try
                {
                    return _self.identifiantAC();
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Read accessor for certificatAC attribute
     * @return the attribute value
     */
    public MessagerieSecurisee.Certificat certificatAC()
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try {
                    org.omg.CORBA.portable.OutputStream _output = this._request("_get_certificatAC",true);
                    _input = this._invoke(_output);
                    return MessagerieSecurisee.CertificatHelper.read(_input);
                } catch (final org.omg.CORBA.portable.RemarshalException _exception) {
                    continue;
                } catch (final org.omg.CORBA.portable.ApplicationException _exception) {
                    final String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                } finally {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_certificatAC",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.ACOperations _self = (MessagerieSecurisee.ACOperations) _so.servant;
                try
                {
                    return _self.certificatAC();
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation creationDeCertificat
     */
    public MessagerieSecurisee.Certificat creationDeCertificat(String nomUtilisateur, MessagerieSecurisee.ListUsages usages, String CP, MessagerieSecurisee.AC Aclevel)
        throws MessagerieSecurisee.CertificatDejaCree
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("creationDeCertificat",true);
                    _output.write_string(nomUtilisateur);
                    MessagerieSecurisee.ListUsagesHelper.write(_output,usages);
                    _output.write_string(CP);
                    MessagerieSecurisee.ACHelper.write(_output,Aclevel);
                    _input = this._invoke(_output);
                    MessagerieSecurisee.Certificat _arg_ret = MessagerieSecurisee.CertificatHelper.read(_input);
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatDejaCreeHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatDejaCreeHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creationDeCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.ACOperations _self = (MessagerieSecurisee.ACOperations) _so.servant;
                try
                {
                    return _self.creationDeCertificat( nomUtilisateur,  usages,  CP,  Aclevel);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demandeDeSuspension
     */
    public void demandeDeSuspension(String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeDeSuspension",true);
                    _output.write_string(identifiantCertificatUtilisateur);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeDeSuspension",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.ACOperations _self = (MessagerieSecurisee.ACOperations) _so.servant;
                try
                {
                    _self.demandeDeSuspension( identifiantCertificatUtilisateur);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demandeDeRevocation
     */
    public void demandeDeRevocation(String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeDeRevocation",true);
                    _output.write_string(identifiantCertificatUtilisateur);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeDeRevocation",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.ACOperations _self = (MessagerieSecurisee.ACOperations) _so.servant;
                try
                {
                    _self.demandeDeRevocation( identifiantCertificatUtilisateur);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demandeValidationCertificat
     */
    public boolean demandeValidationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeValidationCertificat",true);
                    MessagerieSecurisee.CertificatHelper.write(_output,certificatUtilisateur);
                    _input = this._invoke(_output);
                    boolean _arg_ret = _input.read_boolean();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeValidationCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.ACOperations _self = (MessagerieSecurisee.ACOperations) _so.servant;
                try
                {
                    return _self.demandeValidationCertificat( certificatUtilisateur);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demandeVerificationCertificat
     */
    public boolean demandeVerificationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeVerificationCertificat",true);
                    MessagerieSecurisee.CertificatHelper.write(_output,certificatUtilisateur);
                    _input = this._invoke(_output);
                    boolean _arg_ret = _input.read_boolean();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeVerificationCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.ACOperations _self = (MessagerieSecurisee.ACOperations) _so.servant;
                try
                {
                    return _self.demandeVerificationCertificat( certificatUtilisateur);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

}
