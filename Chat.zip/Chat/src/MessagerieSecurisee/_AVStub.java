package MessagerieSecurisee;

/**
 * Interface definition : AV
 * 
 * @author OpenORB Compiler
 */
public class _AVStub extends org.omg.CORBA.portable.ObjectImpl
        implements AV
{
    static final String[] _ids_list =
    {
        "IDL:MessagerieSecurisee/AV:1.0"
    };

    public String[] _ids()
    {
     return _ids_list;
    }

    private final static Class _opsClass = MessagerieSecurisee.AVOperations.class;

    /**
     * Operation demandeValidationCertificat
     */
    public boolean demandeValidationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeValidationCertificat",true);
                    MessagerieSecurisee.CertificatHelper.write(_output,certificatUtilisateur);
                    _input = this._invoke(_output);
                    boolean _arg_ret = _input.read_boolean();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeValidationCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.AVOperations _self = (MessagerieSecurisee.AVOperations) _so.servant;
                try
                {
                    return _self.demandeValidationCertificat( certificatUtilisateur);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demandeVerificationCertificat
     */
    public boolean demandeVerificationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeVerificationCertificat",true);
                    MessagerieSecurisee.CertificatHelper.write(_output,certificatUtilisateur);
                    _input = this._invoke(_output);
                    boolean _arg_ret = _input.read_boolean();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeVerificationCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.AVOperations _self = (MessagerieSecurisee.AVOperations) _so.servant;
                try
                {
                    return _self.demandeVerificationCertificat( certificatUtilisateur);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

}
