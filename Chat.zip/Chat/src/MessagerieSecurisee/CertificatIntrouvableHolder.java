package MessagerieSecurisee;

/**
 * Holder class for : CertificatIntrouvable
 * 
 * @author OpenORB Compiler
 */
final public class CertificatIntrouvableHolder
        implements org.omg.CORBA.portable.Streamable
{
    /**
     * Internal CertificatIntrouvable value
     */
    public MessagerieSecurisee.CertificatIntrouvable value;

    /**
     * Default constructor
     */
    public CertificatIntrouvableHolder()
    { }

    /**
     * Constructor with value initialisation
     * @param initial the initial value
     */
    public CertificatIntrouvableHolder(MessagerieSecurisee.CertificatIntrouvable initial)
    {
        value = initial;
    }

    /**
     * Read CertificatIntrouvable from a marshalled stream
     * @param istream the input stream
     */
    public void _read(org.omg.CORBA.portable.InputStream istream)
    {
        value = CertificatIntrouvableHelper.read(istream);
    }

    /**
     * Write CertificatIntrouvable into a marshalled stream
     * @param ostream the output stream
     */
    public void _write(org.omg.CORBA.portable.OutputStream ostream)
    {
        CertificatIntrouvableHelper.write(ostream,value);
    }

    /**
     * Return the CertificatIntrouvable TypeCode
     * @return a TypeCode
     */
    public org.omg.CORBA.TypeCode _type()
    {
        return CertificatIntrouvableHelper.type();
    }

}
