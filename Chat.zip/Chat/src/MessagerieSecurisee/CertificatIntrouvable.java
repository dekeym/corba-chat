package MessagerieSecurisee;

/**
 * Exception definition : CertificatIntrouvable
 * 
 * @author OpenORB Compiler
 */
public final class CertificatIntrouvable extends org.omg.CORBA.UserException
{
    /**
     * Exception member raisonCertificatIntrouvable
     */
    public String raisonCertificatIntrouvable;

    /**
     * Default constructor
     */
    public CertificatIntrouvable()
    {
        super(CertificatIntrouvableHelper.id());
    }

    /**
     * Constructor with fields initialization
     * @param raisonCertificatIntrouvable raisonCertificatIntrouvable exception member
     */
    public CertificatIntrouvable(String raisonCertificatIntrouvable)
    {
        super(CertificatIntrouvableHelper.id());
        this.raisonCertificatIntrouvable = raisonCertificatIntrouvable;
    }

    /**
     * Full constructor with fields initialization
     * @param raisonCertificatIntrouvable raisonCertificatIntrouvable exception member
     */
    public CertificatIntrouvable(String orb_reason, String raisonCertificatIntrouvable)
    {
        super(CertificatIntrouvableHelper.id() +" " +  orb_reason);
        this.raisonCertificatIntrouvable = raisonCertificatIntrouvable;
    }

}
