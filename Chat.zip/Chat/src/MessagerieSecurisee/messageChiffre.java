package MessagerieSecurisee;

/**
 * Exception definition : messageChiffre
 * 
 * @author OpenORB Compiler
 */
public final class messageChiffre extends org.omg.CORBA.UserException
{
    /**
     * Exception member raisonmsg
     */
    public String raisonmsg;

    /**
     * Default constructor
     */
    public messageChiffre()
    {
        super(messageChiffreHelper.id());
    }

    /**
     * Constructor with fields initialization
     * @param raisonmsg raisonmsg exception member
     */
    public messageChiffre(String raisonmsg)
    {
        super(messageChiffreHelper.id());
        this.raisonmsg = raisonmsg;
    }

    /**
     * Full constructor with fields initialization
     * @param raisonmsg raisonmsg exception member
     */
    public messageChiffre(String orb_reason, String raisonmsg)
    {
        super(messageChiffreHelper.id() +" " +  orb_reason);
        this.raisonmsg = raisonmsg;
    }

}
