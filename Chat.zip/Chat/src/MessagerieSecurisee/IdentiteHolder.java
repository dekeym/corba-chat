package MessagerieSecurisee;

/**
 * Holder class for : Identite
 * 
 * @author OpenORB Compiler
 */
final public class IdentiteHolder
        implements org.omg.CORBA.portable.Streamable
{
    /**
     * Internal Identite value
     */
    public MessagerieSecurisee.Identite value;

    /**
     * Default constructor
     */
    public IdentiteHolder()
    { }

    /**
     * Constructor with value initialisation
     * @param initial the initial value
     */
    public IdentiteHolder(MessagerieSecurisee.Identite initial)
    {
        value = initial;
    }

    /**
     * Read Identite from a marshalled stream
     * @param istream the input stream
     */
    public void _read(org.omg.CORBA.portable.InputStream istream)
    {
        value = IdentiteHelper.read(istream);
    }

    /**
     * Write Identite into a marshalled stream
     * @param ostream the output stream
     */
    public void _write(org.omg.CORBA.portable.OutputStream ostream)
    {
        IdentiteHelper.write(ostream,value);
    }

    /**
     * Return the Identite TypeCode
     * @return a TypeCode
     */
    public org.omg.CORBA.TypeCode _type()
    {
        return IdentiteHelper.type();
    }

}
