package MessagerieSecurisee;

/**
 * Interface definition : Utilisateur
 * 
 * @author OpenORB Compiler
 */
public abstract class UtilisateurPOA extends org.omg.PortableServer.Servant
        implements UtilisateurOperations, org.omg.CORBA.portable.InvokeHandler
{
    public Utilisateur _this()
    {
        return UtilisateurHelper.narrow(_this_object());
    }

    public Utilisateur _this(org.omg.CORBA.ORB orb)
    {
        return UtilisateurHelper.narrow(_this_object(orb));
    }

    private static String [] _ids_list =
    {
        "IDL:MessagerieSecurisee/Utilisateur:1.0"
    };

    public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte [] objectId)
    {
        return _ids_list;
    }

    public final org.omg.CORBA.portable.OutputStream _invoke(final String opName,
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler)
    {

        if (opName.equals("demanderCertificat")) {
                return _invoke_demanderCertificat(_is, handler);
        } else if (opName.equals("transfererMessage")) {
                return _invoke_transfererMessage(_is, handler);
        } else if (opName.equals("transfererMessageSign")) {
                return _invoke_transfererMessageSign(_is, handler);
        } else if (opName.equals("verifCertificat")) {
                return _invoke_verifCertificat(_is, handler);
        } else {
            throw new org.omg.CORBA.BAD_OPERATION(opName);
        }
    }

    // helper methods
    private org.omg.CORBA.portable.OutputStream _invoke_transfererMessage(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Message arg0_in = MessagerieSecurisee.MessageHelper.read(_is);

        try
        {
            transfererMessage(arg0_in);

            _output = handler.createReply();

        }
        catch (MessagerieSecurisee.messageChiffre _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.messageChiffreHelper.write(_output,_exception);
        }
        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_transfererMessageSign(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Message arg0_in = MessagerieSecurisee.MessageHelper.read(_is);
        short arg1_in = _is.read_short();
        MessagerieSecurisee.Certificat arg2_in = MessagerieSecurisee.CertificatHelper.read(_is);

        try
        {
            transfererMessageSign(arg0_in, arg1_in, arg2_in);

            _output = handler.createReply();

        }
        catch (MessagerieSecurisee.messageChiffre _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.messageChiffreHelper.write(_output,_exception);
        }
        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_demanderCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();

        MessagerieSecurisee.Certificat _arg_result = demanderCertificat(arg0_in);

        _output = handler.createReply();
        MessagerieSecurisee.CertificatHelper.write(_output,_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_verifCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        MessagerieSecurisee.Certificat arg1_in = MessagerieSecurisee.CertificatHelper.read(_is);

        boolean _arg_result = verifCertificat(arg0_in, arg1_in);

        _output = handler.createReply();
        _output.write_boolean(_arg_result);

        return _output;
    }

}
