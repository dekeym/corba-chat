package MessagerieSecurisee;

/**
 * Interface definition : AE
 * 
 * @author OpenORB Compiler
 */
public abstract class AEPOA extends org.omg.PortableServer.Servant
        implements AEOperations, org.omg.CORBA.portable.InvokeHandler
{
    public AE _this()
    {
        return AEHelper.narrow(_this_object());
    }

    public AE _this(org.omg.CORBA.ORB orb)
    {
        return AEHelper.narrow(_this_object(orb));
    }

    private static String [] _ids_list =
    {
        "IDL:MessagerieSecurisee/AE:1.0"
    };

    public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte [] objectId)
    {
        return _ids_list;
    }

    public final org.omg.CORBA.portable.OutputStream _invoke(final String opName,
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler)
    {

        if (opName.equals("creationDeCertificat")) {
                return _invoke_creationDeCertificat(_is, handler);
        } else if (opName.equals("demandeDeRevocation")) {
                return _invoke_demandeDeRevocation(_is, handler);
        } else if (opName.equals("demandeDeSuspension")) {
                return _invoke_demandeDeSuspension(_is, handler);
        } else {
            throw new org.omg.CORBA.BAD_OPERATION(opName);
        }
    }

    // helper methods
    private org.omg.CORBA.portable.OutputStream _invoke_creationDeCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Identite arg0_in = MessagerieSecurisee.IdentiteHelper.read(_is);
        MessagerieSecurisee.ListUsages arg1_in = MessagerieSecurisee.ListUsagesHelper.read(_is);
        String arg2_in = _is.read_string();

        try
        {
            MessagerieSecurisee.Certificat _arg_result = creationDeCertificat(arg0_in, arg1_in, arg2_in);

            _output = handler.createReply();
            MessagerieSecurisee.CertificatHelper.write(_output,_arg_result);

        }
        catch (MessagerieSecurisee.CertificatDejaCree _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.CertificatDejaCreeHelper.write(_output,_exception);
        }
        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_demandeDeSuspension(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Identite arg0_in = MessagerieSecurisee.IdentiteHelper.read(_is);
        String arg1_in = _is.read_string();

        try
        {
            demandeDeSuspension(arg0_in, arg1_in);

            _output = handler.createReply();

        }
        catch (MessagerieSecurisee.CertificatIntrouvable _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.CertificatIntrouvableHelper.write(_output,_exception);
        }
        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_demandeDeRevocation(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Identite arg0_in = MessagerieSecurisee.IdentiteHelper.read(_is);
        String arg1_in = _is.read_string();

        try
        {
            demandeDeRevocation(arg0_in, arg1_in);

            _output = handler.createReply();

        }
        catch (MessagerieSecurisee.CertificatIntrouvable _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.CertificatIntrouvableHelper.write(_output,_exception);
        }
        return _output;
    }

}
