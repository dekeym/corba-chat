package MessagerieSecurisee;

/**
 * Interface definition : Porteur
 * 
 * @author OpenORB Compiler
 */
public interface Porteur extends PorteurOperations, MessagerieSecurisee.Utilisateur, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
