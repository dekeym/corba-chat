package MessagerieSecurisee;

/**
 * Struct definition : Message
 * 
 * @author OpenORB Compiler
*/
public final class Message implements org.omg.CORBA.portable.IDLEntity
{
    /**
     * Struct member chiffre
     */
    public boolean chiffre;

    /**
     * Struct member signature
     */
    public String signature;

    /**
     * Struct member message
     */
    public String message;

    /**
     * Struct member expediteur
     */
    public String expediteur;

    /**
     * Default constructor
     */
    public Message()
    { }

    /**
     * Constructor with fields initialization
     * @param chiffre chiffre struct member
     * @param signature signature struct member
     * @param message message struct member
     * @param expediteur expediteur struct member
     */
    public Message(boolean chiffre, String signature, String message, String expediteur)
    {
        this.chiffre = chiffre;
        this.signature = signature;
        this.message = message;
        this.expediteur = expediteur;
    }

}
