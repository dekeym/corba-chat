package MessagerieSecurisee;

/**
 * Interface definition : AE
 * 
 * @author OpenORB Compiler
 */
public class _AEStub extends org.omg.CORBA.portable.ObjectImpl
        implements AE
{
    static final String[] _ids_list =
    {
        "IDL:MessagerieSecurisee/AE:1.0"
    };

    public String[] _ids()
    {
     return _ids_list;
    }

    private final static Class _opsClass = MessagerieSecurisee.AEOperations.class;

    /**
     * Operation creationDeCertificat
     */
    public MessagerieSecurisee.Certificat creationDeCertificat(MessagerieSecurisee.Identite identiteUtilisateur, MessagerieSecurisee.ListUsages usages, String CP)
        throws MessagerieSecurisee.CertificatDejaCree
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("creationDeCertificat",true);
                    MessagerieSecurisee.IdentiteHelper.write(_output,identiteUtilisateur);
                    MessagerieSecurisee.ListUsagesHelper.write(_output,usages);
                    _output.write_string(CP);
                    _input = this._invoke(_output);
                    MessagerieSecurisee.Certificat _arg_ret = MessagerieSecurisee.CertificatHelper.read(_input);
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatDejaCreeHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatDejaCreeHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creationDeCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.AEOperations _self = (MessagerieSecurisee.AEOperations) _so.servant;
                try
                {
                    return _self.creationDeCertificat( identiteUtilisateur,  usages,  CP);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demandeDeSuspension
     */
    public void demandeDeSuspension(MessagerieSecurisee.Identite identiteUtilisateur, String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeDeSuspension",true);
                    MessagerieSecurisee.IdentiteHelper.write(_output,identiteUtilisateur);
                    _output.write_string(identifiantCertificatUtilisateur);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeDeSuspension",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.AEOperations _self = (MessagerieSecurisee.AEOperations) _so.servant;
                try
                {
                    _self.demandeDeSuspension( identiteUtilisateur,  identifiantCertificatUtilisateur);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demandeDeRevocation
     */
    public void demandeDeRevocation(MessagerieSecurisee.Identite identiteUtilisateur, String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demandeDeRevocation",true);
                    MessagerieSecurisee.IdentiteHelper.write(_output,identiteUtilisateur);
                    _output.write_string(identifiantCertificatUtilisateur);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demandeDeRevocation",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.AEOperations _self = (MessagerieSecurisee.AEOperations) _so.servant;
                try
                {
                    _self.demandeDeRevocation( identiteUtilisateur,  identifiantCertificatUtilisateur);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

}
