package MessagerieSecurisee;

/**
 * Holder class for : messageChiffre
 * 
 * @author OpenORB Compiler
 */
final public class messageChiffreHolder
        implements org.omg.CORBA.portable.Streamable
{
    /**
     * Internal messageChiffre value
     */
    public MessagerieSecurisee.messageChiffre value;

    /**
     * Default constructor
     */
    public messageChiffreHolder()
    { }

    /**
     * Constructor with value initialisation
     * @param initial the initial value
     */
    public messageChiffreHolder(MessagerieSecurisee.messageChiffre initial)
    {
        value = initial;
    }

    /**
     * Read messageChiffre from a marshalled stream
     * @param istream the input stream
     */
    public void _read(org.omg.CORBA.portable.InputStream istream)
    {
        value = messageChiffreHelper.read(istream);
    }

    /**
     * Write messageChiffre into a marshalled stream
     * @param ostream the output stream
     */
    public void _write(org.omg.CORBA.portable.OutputStream ostream)
    {
        messageChiffreHelper.write(ostream,value);
    }

    /**
     * Return the messageChiffre TypeCode
     * @return a TypeCode
     */
    public org.omg.CORBA.TypeCode _type()
    {
        return messageChiffreHelper.type();
    }

}
