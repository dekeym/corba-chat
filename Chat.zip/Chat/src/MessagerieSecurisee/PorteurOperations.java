package MessagerieSecurisee;

/**
 * Interface definition : Porteur
 * 
 * @author OpenORB Compiler
 */
public interface PorteurOperations extends MessagerieSecurisee.UtilisateurOperations
{
    /**
     * Operation getCertificatUtilisateur
     */
    public MessagerieSecurisee.Certificat getCertificatUtilisateur(String identifiantCertificat);

    /**
     * Operation ajouterCertificat
     */
    public void ajouterCertificat(MessagerieSecurisee.Certificat cert, MessagerieSecurisee.ListUsages usage);

    /**
     * Operation suprimerCertificat
     */
    public void suprimerCertificat(String cert);

    /**
     * Operation listCertificat
     */
    public String listCertificat();

    /**
     * Operation dechiffrerMsg
     */
    public void dechiffrerMsg(String sign, String msgChiffre, MessagerieSecurisee.Utilisateur user, String expediteur)
        throws MessagerieSecurisee.CertificatIntrouvable;

    /**
     * Operation dechiffrerMsgSign
     */
    public void dechiffrerMsgSign(String msgChiffre, MessagerieSecurisee.Utilisateur user, MessagerieSecurisee.Utilisateur expediteurUser, String expediteur, short hash, MessagerieSecurisee.Certificat cert);

    /**
     * Operation signerMsg
     */
    public void signerMsg(MessagerieSecurisee.Message msg);

    /**
     * Operation transfererMsgUtilisateur
     */
    public void transfererMsgUtilisateur(String sign, String msgDech, MessagerieSecurisee.Utilisateur user, String expediteur);

}
