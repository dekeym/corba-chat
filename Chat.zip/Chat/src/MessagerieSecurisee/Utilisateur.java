package MessagerieSecurisee;

/**
 * Interface definition : Utilisateur
 * 
 * @author OpenORB Compiler
 */
public interface Utilisateur extends UtilisateurOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
