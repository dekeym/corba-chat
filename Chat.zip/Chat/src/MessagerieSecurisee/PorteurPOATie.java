package MessagerieSecurisee;

/**
 * Interface definition : Porteur
 * 
 * @author OpenORB Compiler
 */
public class PorteurPOATie extends PorteurPOA
{

    //
    // Private reference to implementation object
    //
    private PorteurOperations _tie;

    //
    // Private reference to POA
    //
    private org.omg.PortableServer.POA _poa;

    /**
     * Constructor
     */
    public PorteurPOATie(PorteurOperations tieObject)
    {
        _tie = tieObject;
    }

    /**
     * Constructor
     */
    public PorteurPOATie(PorteurOperations tieObject, org.omg.PortableServer.POA poa)
    {
        _tie = tieObject;
        _poa = poa;
    }

    /**
     * Get the delegate
     */
    public PorteurOperations _delegate()
    {
        return _tie;
    }

    /**
     * Set the delegate
     */
    public void _delegate(PorteurOperations delegate_)
    {
        _tie = delegate_;
    }

    /**
     * _default_POA method
     */
    public org.omg.PortableServer.POA _default_POA()
    {
        if (_poa != null)
            return _poa;
        else
            return super._default_POA();
    }

    /**
     * Operation getCertificatUtilisateur
     */
    public MessagerieSecurisee.Certificat getCertificatUtilisateur(String identifiantCertificat)
    {
        return _tie.getCertificatUtilisateur( identifiantCertificat);
    }

    /**
     * Operation ajouterCertificat
     */
    public void ajouterCertificat(MessagerieSecurisee.Certificat cert, MessagerieSecurisee.ListUsages usage)
    {
        _tie.ajouterCertificat( cert,  usage);
    }

    /**
     * Operation suprimerCertificat
     */
    public void suprimerCertificat(String cert)
    {
        _tie.suprimerCertificat( cert);
    }

    /**
     * Operation listCertificat
     */
    public String listCertificat()
    {
        return _tie.listCertificat();
    }

    /**
     * Operation dechiffrerMsg
     */
    public void dechiffrerMsg(String sign, String msgChiffre, MessagerieSecurisee.Utilisateur user, String expediteur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        _tie.dechiffrerMsg( sign,  msgChiffre,  user,  expediteur);
    }

    /**
     * Operation dechiffrerMsgSign
     */
    public void dechiffrerMsgSign(String msgChiffre, MessagerieSecurisee.Utilisateur user, MessagerieSecurisee.Utilisateur expediteurUser, String expediteur, short hash, MessagerieSecurisee.Certificat cert)
    {
        _tie.dechiffrerMsgSign( msgChiffre,  user,  expediteurUser,  expediteur,  hash,  cert);
    }

    /**
     * Operation signerMsg
     */
    public void signerMsg(MessagerieSecurisee.Message msg)
    {
        _tie.signerMsg( msg);
    }

    /**
     * Operation transfererMsgUtilisateur
     */
    public void transfererMsgUtilisateur(String sign, String msgDech, MessagerieSecurisee.Utilisateur user, String expediteur)
    {
        _tie.transfererMsgUtilisateur( sign,  msgDech,  user,  expediteur);
    }

    /**
     * Operation transfererMessage
     */
    public void transfererMessage(MessagerieSecurisee.Message msg)
        throws MessagerieSecurisee.messageChiffre
    {
        _tie.transfererMessage( msg);
    }

    /**
     * Operation transfererMessageSign
     */
    public void transfererMessageSign(MessagerieSecurisee.Message msg, short hash, MessagerieSecurisee.Certificat cert)
        throws MessagerieSecurisee.messageChiffre
    {
        _tie.transfererMessageSign( msg,  hash,  cert);
    }

    /**
     * Operation demanderCertificat
     */
    public MessagerieSecurisee.Certificat demanderCertificat(String usage)
    {
        return _tie.demanderCertificat( usage);
    }

    /**
     * Operation verifCertificat
     */
    public boolean verifCertificat(String usage, MessagerieSecurisee.Certificat cert)
    {
        return _tie.verifCertificat( usage,  cert);
    }

}
