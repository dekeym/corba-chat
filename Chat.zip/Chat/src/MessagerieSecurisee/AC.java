package MessagerieSecurisee;

/**
 * Interface definition : AC
 * 
 * @author OpenORB Compiler
 */
public interface AC extends ACOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
