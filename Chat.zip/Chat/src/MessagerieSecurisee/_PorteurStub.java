package MessagerieSecurisee;

/**
 * Interface definition : Porteur
 * 
 * @author OpenORB Compiler
 */
public class _PorteurStub extends org.omg.CORBA.portable.ObjectImpl
        implements Porteur
{
    static final String[] _ids_list =
    {
        "IDL:MessagerieSecurisee/Porteur:1.0", 
        "IDL:MessagerieSecurisee/Utilisateur:1.0"
    };

    public String[] _ids()
    {
     return _ids_list;
    }

    private final static Class _opsClass = MessagerieSecurisee.PorteurOperations.class;

    /**
     * Operation getCertificatUtilisateur
     */
    public MessagerieSecurisee.Certificat getCertificatUtilisateur(String identifiantCertificat)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("getCertificatUtilisateur",true);
                    _output.write_string(identifiantCertificat);
                    _input = this._invoke(_output);
                    MessagerieSecurisee.Certificat _arg_ret = MessagerieSecurisee.CertificatHelper.read(_input);
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("getCertificatUtilisateur",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    return _self.getCertificatUtilisateur( identifiantCertificat);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation ajouterCertificat
     */
    public void ajouterCertificat(MessagerieSecurisee.Certificat cert, MessagerieSecurisee.ListUsages usage)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("ajouterCertificat",true);
                    MessagerieSecurisee.CertificatHelper.write(_output,cert);
                    MessagerieSecurisee.ListUsagesHelper.write(_output,usage);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("ajouterCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    _self.ajouterCertificat( cert,  usage);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation suprimerCertificat
     */
    public void suprimerCertificat(String cert)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("suprimerCertificat",true);
                    _output.write_string(cert);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("suprimerCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    _self.suprimerCertificat( cert);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation listCertificat
     */
    public String listCertificat()
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("listCertificat",true);
                    _input = this._invoke(_output);
                    String _arg_ret = _input.read_string();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("listCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    return _self.listCertificat();
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation dechiffrerMsg
     */
    public void dechiffrerMsg(String sign, String msgChiffre, MessagerieSecurisee.Utilisateur user, String expediteur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("dechiffrerMsg",true);
                    _output.write_string(sign);
                    _output.write_string(msgChiffre);
                    MessagerieSecurisee.UtilisateurHelper.write(_output,user);
                    _output.write_string(expediteur);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.CertificatIntrouvableHelper.id()))
                    {
                        throw MessagerieSecurisee.CertificatIntrouvableHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("dechiffrerMsg",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    _self.dechiffrerMsg( sign,  msgChiffre,  user,  expediteur);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation dechiffrerMsgSign
     */
    public void dechiffrerMsgSign(String msgChiffre, MessagerieSecurisee.Utilisateur user, MessagerieSecurisee.Utilisateur expediteurUser, String expediteur, short hash, MessagerieSecurisee.Certificat cert)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("dechiffrerMsgSign",true);
                    _output.write_string(msgChiffre);
                    MessagerieSecurisee.UtilisateurHelper.write(_output,user);
                    MessagerieSecurisee.UtilisateurHelper.write(_output,expediteurUser);
                    _output.write_string(expediteur);
                    _output.write_short(hash);
                    MessagerieSecurisee.CertificatHelper.write(_output,cert);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("dechiffrerMsgSign",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    _self.dechiffrerMsgSign( msgChiffre,  user,  expediteurUser,  expediteur,  hash,  cert);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation signerMsg
     */
    public void signerMsg(MessagerieSecurisee.Message msg)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("signerMsg",true);
                    MessagerieSecurisee.MessageHelper.write(_output,msg);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("signerMsg",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    _self.signerMsg( msg);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation transfererMsgUtilisateur
     */
    public void transfererMsgUtilisateur(String sign, String msgDech, MessagerieSecurisee.Utilisateur user, String expediteur)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("transfererMsgUtilisateur",true);
                    _output.write_string(sign);
                    _output.write_string(msgDech);
                    MessagerieSecurisee.UtilisateurHelper.write(_output,user);
                    _output.write_string(expediteur);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("transfererMsgUtilisateur",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.PorteurOperations _self = (MessagerieSecurisee.PorteurOperations) _so.servant;
                try
                {
                    _self.transfererMsgUtilisateur( sign,  msgDech,  user,  expediteur);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation transfererMessage
     */
    public void transfererMessage(MessagerieSecurisee.Message msg)
        throws MessagerieSecurisee.messageChiffre
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("transfererMessage",true);
                    MessagerieSecurisee.MessageHelper.write(_output,msg);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.messageChiffreHelper.id()))
                    {
                        throw MessagerieSecurisee.messageChiffreHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("transfererMessage",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    _self.transfererMessage( msg);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation transfererMessageSign
     */
    public void transfererMessageSign(MessagerieSecurisee.Message msg, short hash, MessagerieSecurisee.Certificat cert)
        throws MessagerieSecurisee.messageChiffre
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("transfererMessageSign",true);
                    MessagerieSecurisee.MessageHelper.write(_output,msg);
                    _output.write_short(hash);
                    MessagerieSecurisee.CertificatHelper.write(_output,cert);
                    _input = this._invoke(_output);
                    return;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    if (_exception_id.equals(MessagerieSecurisee.messageChiffreHelper.id()))
                    {
                        throw MessagerieSecurisee.messageChiffreHelper.read(_exception.getInputStream());
                    }

                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("transfererMessageSign",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    _self.transfererMessageSign( msg,  hash,  cert);
                    return;
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation demanderCertificat
     */
    public MessagerieSecurisee.Certificat demanderCertificat(String usage)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("demanderCertificat",true);
                    _output.write_string(usage);
                    _input = this._invoke(_output);
                    MessagerieSecurisee.Certificat _arg_ret = MessagerieSecurisee.CertificatHelper.read(_input);
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("demanderCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    return _self.demanderCertificat( usage);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation verifCertificat
     */
    public boolean verifCertificat(String usage, MessagerieSecurisee.Certificat cert)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("verifCertificat",true);
                    _output.write_string(usage);
                    MessagerieSecurisee.CertificatHelper.write(_output,cert);
                    _input = this._invoke(_output);
                    boolean _arg_ret = _input.read_boolean();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("verifCertificat",_opsClass);
                if (_so == null)
                   continue;
                MessagerieSecurisee.UtilisateurOperations _self = (MessagerieSecurisee.UtilisateurOperations) _so.servant;
                try
                {
                    return _self.verifCertificat( usage,  cert);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

}
