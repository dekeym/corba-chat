package MessagerieSecurisee;

/**
 * Exception definition : CertificatDejaCree
 * 
 * @author OpenORB Compiler
 */
public final class CertificatDejaCree extends org.omg.CORBA.UserException
{
    /**
     * Exception member raisonCertificatDejaCree
     */
    public String raisonCertificatDejaCree;

    /**
     * Default constructor
     */
    public CertificatDejaCree()
    {
        super(CertificatDejaCreeHelper.id());
    }

    /**
     * Constructor with fields initialization
     * @param raisonCertificatDejaCree raisonCertificatDejaCree exception member
     */
    public CertificatDejaCree(String raisonCertificatDejaCree)
    {
        super(CertificatDejaCreeHelper.id());
        this.raisonCertificatDejaCree = raisonCertificatDejaCree;
    }

    /**
     * Full constructor with fields initialization
     * @param raisonCertificatDejaCree raisonCertificatDejaCree exception member
     */
    public CertificatDejaCree(String orb_reason, String raisonCertificatDejaCree)
    {
        super(CertificatDejaCreeHelper.id() +" " +  orb_reason);
        this.raisonCertificatDejaCree = raisonCertificatDejaCree;
    }

}
