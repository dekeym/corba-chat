package MessagerieSecurisee;

/**
 * Interface definition : AV
 * 
 * @author OpenORB Compiler
 */
public interface AV extends AVOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
