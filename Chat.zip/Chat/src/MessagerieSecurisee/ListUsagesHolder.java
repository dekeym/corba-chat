package MessagerieSecurisee;

/**
 * Holder class for : ListUsages
 * 
 * @author OpenORB Compiler
 */
final public class ListUsagesHolder
        implements org.omg.CORBA.portable.Streamable
{
    /**
     * Internal ListUsages value
     */
    public MessagerieSecurisee.ListUsages value;

    /**
     * Default constructor
     */
    public ListUsagesHolder()
    { }

    /**
     * Constructor with value initialisation
     * @param initial the initial value
     */
    public ListUsagesHolder(MessagerieSecurisee.ListUsages initial)
    {
        value = initial;
    }

    /**
     * Read ListUsages from a marshalled stream
     * @param istream the input stream
     */
    public void _read(org.omg.CORBA.portable.InputStream istream)
    {
        value = ListUsagesHelper.read(istream);
    }

    /**
     * Write ListUsages into a marshalled stream
     * @param ostream the output stream
     */
    public void _write(org.omg.CORBA.portable.OutputStream ostream)
    {
        ListUsagesHelper.write(ostream,value);
    }

    /**
     * Return the ListUsages TypeCode
     * @return a TypeCode
     */
    public org.omg.CORBA.TypeCode _type()
    {
        return ListUsagesHelper.type();
    }

}
