package MessagerieSecurisee;

/**
 * Interface definition : AE
 * 
 * @author OpenORB Compiler
 */
public interface AEOperations
{
    /**
     * Operation creationDeCertificat
     */
    public MessagerieSecurisee.Certificat creationDeCertificat(MessagerieSecurisee.Identite identiteUtilisateur, MessagerieSecurisee.ListUsages usages, String CP)
        throws MessagerieSecurisee.CertificatDejaCree;

    /**
     * Operation demandeDeSuspension
     */
    public void demandeDeSuspension(MessagerieSecurisee.Identite identiteUtilisateur, String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

    /**
     * Operation demandeDeRevocation
     */
    public void demandeDeRevocation(MessagerieSecurisee.Identite identiteUtilisateur, String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

}
