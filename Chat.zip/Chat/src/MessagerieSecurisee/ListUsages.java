package MessagerieSecurisee;

/**
 * Enum definition : ListUsages
 *
 * @author OpenORB Compiler
*/
public final class ListUsages implements org.omg.CORBA.portable.IDLEntity
{
    /**
     * Enum member chiffrement value 
     */
    public static final int _chiffrement = 0;

    /**
     * Enum member chiffrement
     */
    public static final ListUsages chiffrement = new ListUsages(_chiffrement);

    /**
     * Enum member signature value 
     */
    public static final int _signature = 1;

    /**
     * Enum member signature
     */
    public static final ListUsages signature = new ListUsages(_signature);

    /**
     * Enum member revocation value 
     */
    public static final int _revocation = 2;

    /**
     * Enum member revocation
     */
    public static final ListUsages revocation = new ListUsages(_revocation);

    /**
     * Enum member suspension value 
     */
    public static final int _suspension = 3;

    /**
     * Enum member suspension
     */
    public static final ListUsages suspension = new ListUsages(_suspension);

    /**
     * Internal member value 
     */
    private final int _ListUsages_value;

    /**
     * Private constructor
     * @param  the enum value for this new member
     */
    private ListUsages( final int value )
    {
        _ListUsages_value = value;
    }

    /**
     * Maintains singleton property for serialized enums.
     * Issue 4271: IDL/Java issue, Mapping for IDL enum.
     */
    public java.lang.Object readResolve() throws java.io.ObjectStreamException
    {
        return from_int( value() );
    }

    /**
     * Return the internal member value
     * @return the member value
     */
    public int value()
    {
        return _ListUsages_value;
    }

    /**
     * Return a enum member from its value
     * @param  an enum value
     * @return an enum member
         */
    public static ListUsages from_int(int value)
    {
        switch (value)
        {
        case 0 :
            return chiffrement;
        case 1 :
            return signature;
        case 2 :
            return revocation;
        case 3 :
            return suspension;
        }
        throw new org.omg.CORBA.BAD_OPERATION();
    }

    /**
     * Return a string representation
     * @return a string representation of the enumeration
     */
    public java.lang.String toString()
    {
        switch (_ListUsages_value)
        {
        case 0 :
            return "chiffrement";
        case 1 :
            return "signature";
        case 2 :
            return "revocation";
        case 3 :
            return "suspension";
        }
        throw new org.omg.CORBA.BAD_OPERATION();
    }

}
