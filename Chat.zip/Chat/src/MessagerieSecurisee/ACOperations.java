package MessagerieSecurisee;

/**
 * Interface definition : AC
 * 
 * @author OpenORB Compiler
 */
public interface ACOperations
{
    /**
     * Read accessor for identifiantAC attribute
     * @return the attribute value
     */
    public String identifiantAC();

    /**
     * Read accessor for certificatAC attribute
     * @return the attribute value
     */
    public MessagerieSecurisee.Certificat certificatAC();

    /**
     * Operation creationDeCertificat
     */
    public MessagerieSecurisee.Certificat creationDeCertificat(String nomUtilisateur, MessagerieSecurisee.ListUsages usages, String CP, MessagerieSecurisee.AC Aclevel)
        throws MessagerieSecurisee.CertificatDejaCree;

    /**
     * Operation demandeDeSuspension
     */
    public void demandeDeSuspension(String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

    /**
     * Operation demandeDeRevocation
     */
    public void demandeDeRevocation(String identifiantCertificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

    /**
     * Operation demandeValidationCertificat
     */
    public boolean demandeValidationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

    /**
     * Operation demandeVerificationCertificat
     */
    public boolean demandeVerificationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable;

}
