package MessagerieSecurisee;

/**
 * Interface definition : Utilisateur
 * 
 * @author OpenORB Compiler
 */
public interface UtilisateurOperations
{
    /**
     * Operation transfererMessage
     */
    public void transfererMessage(MessagerieSecurisee.Message msg)
        throws MessagerieSecurisee.messageChiffre;

    /**
     * Operation transfererMessageSign
     */
    public void transfererMessageSign(MessagerieSecurisee.Message msg, short hash, MessagerieSecurisee.Certificat cert)
        throws MessagerieSecurisee.messageChiffre;

    /**
     * Operation demanderCertificat
     */
    public MessagerieSecurisee.Certificat demanderCertificat(String usage);

    /**
     * Operation verifCertificat
     */
    public boolean verifCertificat(String usage, MessagerieSecurisee.Certificat cert);

}
