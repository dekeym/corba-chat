package MessagerieSecurisee;

/**
 * Interface definition : AV
 * 
 * @author OpenORB Compiler
 */
public class AVPOATie extends AVPOA
{

    //
    // Private reference to implementation object
    //
    private AVOperations _tie;

    //
    // Private reference to POA
    //
    private org.omg.PortableServer.POA _poa;

    /**
     * Constructor
     */
    public AVPOATie(AVOperations tieObject)
    {
        _tie = tieObject;
    }

    /**
     * Constructor
     */
    public AVPOATie(AVOperations tieObject, org.omg.PortableServer.POA poa)
    {
        _tie = tieObject;
        _poa = poa;
    }

    /**
     * Get the delegate
     */
    public AVOperations _delegate()
    {
        return _tie;
    }

    /**
     * Set the delegate
     */
    public void _delegate(AVOperations delegate_)
    {
        _tie = delegate_;
    }

    /**
     * _default_POA method
     */
    public org.omg.PortableServer.POA _default_POA()
    {
        if (_poa != null)
            return _poa;
        else
            return super._default_POA();
    }

    /**
     * Operation demandeValidationCertificat
     */
    public boolean demandeValidationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        return _tie.demandeValidationCertificat( certificatUtilisateur);
    }

    /**
     * Operation demandeVerificationCertificat
     */
    public boolean demandeVerificationCertificat(MessagerieSecurisee.Certificat certificatUtilisateur)
        throws MessagerieSecurisee.CertificatIntrouvable
    {
        return _tie.demandeVerificationCertificat( certificatUtilisateur);
    }

}
