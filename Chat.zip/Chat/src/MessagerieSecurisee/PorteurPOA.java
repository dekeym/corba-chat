package MessagerieSecurisee;

/**
 * Interface definition : Porteur
 * 
 * @author OpenORB Compiler
 */
public abstract class PorteurPOA extends org.omg.PortableServer.Servant
        implements PorteurOperations, org.omg.CORBA.portable.InvokeHandler
{
    public Porteur _this()
    {
        return PorteurHelper.narrow(_this_object());
    }

    public Porteur _this(org.omg.CORBA.ORB orb)
    {
        return PorteurHelper.narrow(_this_object(orb));
    }

    private static String [] _ids_list =
    {
        "IDL:MessagerieSecurisee/Porteur:1.0", 
        "IDL:MessagerieSecurisee/Utilisateur:1.0"
    };

    public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte [] objectId)
    {
        return _ids_list;
    }

    private static final java.util.Map operationMap = new java.util.HashMap();

    static {
            operationMap.put("ajouterCertificat",
                    new Operation_ajouterCertificat());
            operationMap.put("dechiffrerMsg",
                    new Operation_dechiffrerMsg());
            operationMap.put("dechiffrerMsgSign",
                    new Operation_dechiffrerMsgSign());
            operationMap.put("demanderCertificat",
                    new Operation_demanderCertificat());
            operationMap.put("getCertificatUtilisateur",
                    new Operation_getCertificatUtilisateur());
            operationMap.put("listCertificat",
                    new Operation_listCertificat());
            operationMap.put("signerMsg",
                    new Operation_signerMsg());
            operationMap.put("suprimerCertificat",
                    new Operation_suprimerCertificat());
            operationMap.put("transfererMessage",
                    new Operation_transfererMessage());
            operationMap.put("transfererMessageSign",
                    new Operation_transfererMessageSign());
            operationMap.put("transfererMsgUtilisateur",
                    new Operation_transfererMsgUtilisateur());
            operationMap.put("verifCertificat",
                    new Operation_verifCertificat());
    }

    public final org.omg.CORBA.portable.OutputStream _invoke(final String opName,
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler)
    {

        final AbstractOperation operation = (AbstractOperation)operationMap.get(opName);

        if (null == operation) {
            throw new org.omg.CORBA.BAD_OPERATION(opName);
        }

        return operation.invoke(this, _is, handler);
    }

    // helper methods
    private org.omg.CORBA.portable.OutputStream _invoke_getCertificatUtilisateur(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();

        MessagerieSecurisee.Certificat _arg_result = getCertificatUtilisateur(arg0_in);

        _output = handler.createReply();
        MessagerieSecurisee.CertificatHelper.write(_output,_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_ajouterCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Certificat arg0_in = MessagerieSecurisee.CertificatHelper.read(_is);
        MessagerieSecurisee.ListUsages arg1_in = MessagerieSecurisee.ListUsagesHelper.read(_is);

        ajouterCertificat(arg0_in, arg1_in);

        _output = handler.createReply();

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_suprimerCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();

        suprimerCertificat(arg0_in);

        _output = handler.createReply();

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_listCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;

        String _arg_result = listCertificat();

        _output = handler.createReply();
        _output.write_string(_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_dechiffrerMsg(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        String arg1_in = _is.read_string();
        MessagerieSecurisee.Utilisateur arg2_in = MessagerieSecurisee.UtilisateurHelper.read(_is);
        String arg3_in = _is.read_string();

        try
        {
            dechiffrerMsg(arg0_in, arg1_in, arg2_in, arg3_in);

            _output = handler.createReply();

        }
        catch (MessagerieSecurisee.CertificatIntrouvable _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.CertificatIntrouvableHelper.write(_output,_exception);
        }
        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_dechiffrerMsgSign(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        MessagerieSecurisee.Utilisateur arg1_in = MessagerieSecurisee.UtilisateurHelper.read(_is);
        MessagerieSecurisee.Utilisateur arg2_in = MessagerieSecurisee.UtilisateurHelper.read(_is);
        String arg3_in = _is.read_string();
        short arg4_in = _is.read_short();
        MessagerieSecurisee.Certificat arg5_in = MessagerieSecurisee.CertificatHelper.read(_is);

        dechiffrerMsgSign(arg0_in, arg1_in, arg2_in, arg3_in, arg4_in, arg5_in);

        _output = handler.createReply();

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_signerMsg(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Message arg0_in = MessagerieSecurisee.MessageHelper.read(_is);

        signerMsg(arg0_in);

        _output = handler.createReply();

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_transfererMsgUtilisateur(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        String arg1_in = _is.read_string();
        MessagerieSecurisee.Utilisateur arg2_in = MessagerieSecurisee.UtilisateurHelper.read(_is);
        String arg3_in = _is.read_string();

        transfererMsgUtilisateur(arg0_in, arg1_in, arg2_in, arg3_in);

        _output = handler.createReply();

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_transfererMessage(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Message arg0_in = MessagerieSecurisee.MessageHelper.read(_is);

        try
        {
            transfererMessage(arg0_in);

            _output = handler.createReply();

        }
        catch (MessagerieSecurisee.messageChiffre _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.messageChiffreHelper.write(_output,_exception);
        }
        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_transfererMessageSign(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        MessagerieSecurisee.Message arg0_in = MessagerieSecurisee.MessageHelper.read(_is);
        short arg1_in = _is.read_short();
        MessagerieSecurisee.Certificat arg2_in = MessagerieSecurisee.CertificatHelper.read(_is);

        try
        {
            transfererMessageSign(arg0_in, arg1_in, arg2_in);

            _output = handler.createReply();

        }
        catch (MessagerieSecurisee.messageChiffre _exception)
        {
            _output = handler.createExceptionReply();
            MessagerieSecurisee.messageChiffreHelper.write(_output,_exception);
        }
        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_demanderCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();

        MessagerieSecurisee.Certificat _arg_result = demanderCertificat(arg0_in);

        _output = handler.createReply();
        MessagerieSecurisee.CertificatHelper.write(_output,_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_verifCertificat(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        MessagerieSecurisee.Certificat arg1_in = MessagerieSecurisee.CertificatHelper.read(_is);

        boolean _arg_result = verifCertificat(arg0_in, arg1_in);

        _output = handler.createReply();
        _output.write_boolean(_arg_result);

        return _output;
    }

    // operation classes
    private abstract static class AbstractOperation {
        protected abstract org.omg.CORBA.portable.OutputStream invoke(
                PorteurPOA target,
                org.omg.CORBA.portable.InputStream _is,
                org.omg.CORBA.portable.ResponseHandler handler);
    }

    private static final class Operation_getCertificatUtilisateur extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_getCertificatUtilisateur(_is, handler);
        }
    }

    private static final class Operation_ajouterCertificat extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_ajouterCertificat(_is, handler);
        }
    }

    private static final class Operation_suprimerCertificat extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_suprimerCertificat(_is, handler);
        }
    }

    private static final class Operation_listCertificat extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_listCertificat(_is, handler);
        }
    }

    private static final class Operation_dechiffrerMsg extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_dechiffrerMsg(_is, handler);
        }
    }

    private static final class Operation_dechiffrerMsgSign extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_dechiffrerMsgSign(_is, handler);
        }
    }

    private static final class Operation_signerMsg extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_signerMsg(_is, handler);
        }
    }

    private static final class Operation_transfererMsgUtilisateur extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_transfererMsgUtilisateur(_is, handler);
        }
    }

    private static final class Operation_transfererMessage extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_transfererMessage(_is, handler);
        }
    }

    private static final class Operation_transfererMessageSign extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_transfererMessageSign(_is, handler);
        }
    }

    private static final class Operation_demanderCertificat extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_demanderCertificat(_is, handler);
        }
    }

    private static final class Operation_verifCertificat extends AbstractOperation
    {
        protected org.omg.CORBA.portable.OutputStream invoke(
                final PorteurPOA target,
                final org.omg.CORBA.portable.InputStream _is,
                final org.omg.CORBA.portable.ResponseHandler handler) {
            return target._invoke_verifCertificat(_is, handler);
        }
    }

}
