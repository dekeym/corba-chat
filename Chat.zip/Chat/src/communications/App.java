package communications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Scanner;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import Implementations.AEImpl;
import Implementations.UtilisateurImpl;
import MessagerieSecurisee.AC;
import MessagerieSecurisee.ACHelper;
import MessagerieSecurisee.AE;
import MessagerieSecurisee.AEHelper;
import MessagerieSecurisee.AV;
import MessagerieSecurisee.AVHelper;
import MessagerieSecurisee.CertificatIntrouvable;
import MessagerieSecurisee.Identite;
import MessagerieSecurisee.ListUsages;
import MessagerieSecurisee.Porteur;
import MessagerieSecurisee.PorteurHelper;
import MessagerieSecurisee.Utilisateur;
import MessagerieSecurisee.UtilisateurHelper;

public class App {
		
	public static void main(String[] args) { 
		
		// Intialisation de l'orb
		org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);
		
		int str;
		
		try {
			// Recuperation du naming service
			NamingContext nameRoot=org.omg.CosNaming.NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));
			
			BufferedReader entreeClavier = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("Entrez pseudo ?");
			String pseudo = entreeClavier.readLine();
			
			System.out.println("Entrez votre mot de passe ?");
			String mdp = entreeClavier.readLine();
			
			System.out.println("A quel AE souhaitez-vous vous connecter ?");
			String AEReferant = entreeClavier.readLine();
			
			org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
			nameToFind[0] = new org.omg.CosNaming.NameComponent(AEReferant, "");
			
			// Recherche aupres du naming service
			org.omg.CORBA.Object objC = nameRoot.resolve(nameToFind);

			// Transtypage de l'objet CORBA au type AE
			AE monAE = AEHelper.narrow(objC);
			
			UtilisateurImpl user = new UtilisateurImpl(pseudo);
			user.setAEReferant(monAE);
			
			Scanner sc = new Scanner(System.in);
			afficherMenu();
			str = sc.nextInt();
			
			Identite userIdentity = new Identite(pseudo, mdp);
			
			TalkServer partS = new TalkServer(pseudo, orb, nameRoot);
			partS.enregistrement();
			Thread tS = new Thread(partS);
			tS.start();
			
			String idPorteur = pseudo+".Porteur";
			
			org.omg.CosNaming.NameComponent[] nameToFindx = new org.omg.CosNaming.NameComponent[1];
			nameToFindx[0] = new org.omg.CosNaming.NameComponent(idPorteur, "");
			
			// Recherche aupres du naming service
			org.omg.CORBA.Object objCa = nameRoot.resolve(nameToFindx);

			// Transtypage de l'objet CORBA au type AC
			Porteur porteur = PorteurHelper.narrow(objCa);		
	        
	        user.setMonPorteur(porteur);
	       
			do {
				switch (str) {
					case 1 : 
						user.creationCertificat(userIdentity);
						System.out.println("***** CREATION DE CERTIFICAT COMPLETEE *****");
					
						afficherMenu();
						str = sc.nextInt();
						break;
					case 2:
						user.revocationCertificat(userIdentity);
						System.out.println("***** REVOCATION COMPLETEE *****");
						afficherMenu();
						str = sc.nextInt();
						break;
					case 3:
						user.suspensionCertificat(userIdentity);
						System.out.println("***** SUSPENSION COMPLETEE *****");
						afficherMenu();
						str = sc.nextInt();
						break;
					case 4:
						TalkSender partC = new TalkSender(user, entreeClavier, orb, nameRoot);
						Thread tC = new Thread(partC);
						tC.start();
						break;
				}
				
			} while (str != 0);
			
			
		} catch (InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CannotProceed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public static void afficherMenu()
	{
		System.out.println("---------------------------------------------");
		System.out.println("Que souhaitez-vous faire ?");
		System.out.println("---------------------------------------------");
		System.out.println("Choix 1 : Cr�ation de certificat");
		System.out.println("Choix 2 : R�vocation de certificat");
		System.out.println("Choix 3 : Suspension de certificat");
		System.out.println("Choix 4 : Envoyer un message");
		System.out.println("---------------------------------------------");
		System.out.println("Choix 0 : Quitter");
		System.out.println("---------------------------------------------");
	}

}
