package communications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantAlreadyActive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import Implementations.AEImpl;
import Implementations.AVImpl;
import MessagerieSecurisee.AC;
import MessagerieSecurisee.ACHelper;
import MessagerieSecurisee.AE;
import MessagerieSecurisee.AEHelper;

public class MainAE {
	public static void main(String[] args) { 
		BufferedReader entreeClavier = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Entrez le nom de l'AE ?");
		
		try {
			String nomAE = entreeClavier.readLine();
			
			// Intialisation de l'orb
			org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);
			
			// Recuperation du naming service
			NamingContext nameRoot=org.omg.CosNaming.NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));
			
			// Recuperation du POA
	        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
	        
	        
	        // Creation du servant
	        //*********************
	        AEImpl AeServant = new AEImpl(nomAE);

	        // Activer le servant au sein du POA et recuperer son ID
	        byte[] AvTalkId = rootPOA.activate_object(AeServant);

	        // Activer le POA manager
	        rootPOA.the_POAManager().activate();


	        // Enregistrement dans le service de nommage
	        //*******************************************
	        // Construction du nom a enregistrer
	        org.omg.CosNaming.NameComponent[] nameToRegister = new org.omg.CosNaming.NameComponent[1];
	        nameToRegister[0] = new org.omg.CosNaming.NameComponent(nomAE,"");

	        // Enregistrement de l'objet CORBA dans le service de noms
	        nameRoot.rebind(nameToRegister,rootPOA.servant_to_reference(AeServant));
	        System.out.println("==> Nom '"+ nomAE + "' est enregistre dans le service de noms.");

	        String IORServant = orb.object_to_string(rootPOA.servant_to_reference(AeServant));
	            
			System.out.println("Entrez le nom de l'AC ?");
			
			String nomAC = entreeClavier.readLine();
			
			org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
			nameToFind[0] = new org.omg.CosNaming.NameComponent(nomAC, "");
			
			// Recherche aupres du naming service
			org.omg.CORBA.Object objC = nameRoot.resolve(nameToFind);

			// Transtypage de l'objet CORBA au type AC
			AC monAC = ACHelper.narrow(objC);
			
			AeServant.setMonAc(monAC);
			
			orb.run();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServantNotActive e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WrongPolicy e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CannotProceed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AdapterInactive e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServantAlreadyActive e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
