package communications;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.InvalidName;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import Implementations.UtilisateurImpl;
import MessagerieSecurisee.Certificat;
import MessagerieSecurisee.CertificatIntrouvable;
import MessagerieSecurisee.Message;
import MessagerieSecurisee.Porteur;
import MessagerieSecurisee.PorteurHelper;
import MessagerieSecurisee.Utilisateur;
import MessagerieSecurisee.UtilisateurHelper;
import MessagerieSecurisee.messageChiffre;

public class TalkSender implements Runnable {
	private BufferedReader entreeClavier;
	private UtilisateurImpl user;
	private org.omg.CORBA.ORB orb;
	private org.omg.CosNaming.NamingContext nameRoot;
	
	public TalkSender(UtilisateurImpl user, BufferedReader entreeClavier, ORB orb, NamingContext nameRoot) {
		super();
		this.entreeClavier = entreeClavier;
		this.user = user;
		this.orb = orb;
		this.nameRoot = nameRoot;
	}
	
	public void run() {
		Scanner sc = new Scanner(System.in);
		Scanner content = new Scanner(System.in);
		Message messageAenvoyer;
		int choix;
		String[] args;
		
		do {
			
			System.out.println("---------------------------------------------");
			System.out.println("Quel type de message souhaitez-vous envoyer ?");
			System.out.println("---------------------------------------------");
			System.out.println("Choix 1 : message non s�curis�.");
			System.out.println("Choix 2 : message chiffr�.");
			System.out.println("Choix 3 : message sign�.");
			System.out.println("Choix 4 : message chiffr� et sign�.");
			System.out.println("---------------------------------------------");
					
			choix = sc.nextInt();
			String msg;
						
			// v�rifier pr�sence utilisateur
			// Construction du nom a rechercher
			
			// Saisie du nom de l'objet (si utilisation du service de nommage)
			System.out.println("Entrez destinataire nom ?");
			String destinataire;
			try {
				destinataire = entreeClavier.readLine();
				
				org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
				nameToFind[0] = new org.omg.CosNaming.NameComponent(destinataire, "");
				
				// Recherche aupres du naming service
				org.omg.CORBA.Object objC = getNameRoot().resolve(nameToFind);

				// Transtypage de l'objet CORBA au type convertisseur euro
				Utilisateur destUser = UtilisateurHelper.narrow(objC);
				
				org.omg.CosNaming.NameComponent[] nameToFindPorteur = new org.omg.CosNaming.NameComponent[1];
				nameToFindPorteur[0] = new org.omg.CosNaming.NameComponent(destinataire+".Porteur", "");
				
				// Recherche aupres du naming service
				org.omg.CORBA.Object objCPorteur = getNameRoot().resolve(nameToFindPorteur);

				// Transtypage de l'objet CORBA au type convertisseur euro
				Porteur destUserPorteur = PorteurHelper.narrow(objCPorteur);
				
				// User
				org.omg.CosNaming.NameComponent[] nameToFindUser = new org.omg.CosNaming.NameComponent[1];
				nameToFindUser[0] = new org.omg.CosNaming.NameComponent(user.getNomUtilisateur(), "");
				
				// Recherche aupres du naming service
				org.omg.CORBA.Object objCUser = getNameRoot().resolve(nameToFindUser);

				// Transtypage de l'objet CORBA au type convertisseur euro
				Utilisateur expediteur = UtilisateurHelper.narrow(objCUser);
									
								
				switch (choix) {
					case 1 : 
						do {
							System.out.println("Entrez votre message :");
							msg = content.nextLine();
							messageAenvoyer = new Message(false, "", msg, user.getNomUtilisateur());
							try {
								destUser.transfererMessage(messageAenvoyer);
							} catch (messageChiffre e) {
								e.printStackTrace();
							}
						} while (!msg.equals("FIN_MSG"));
						choix = 0 ;
						break;
						
					case 2 : 
						do {
							System.out.println("Entrez votre message (mode chiffr�) :");
							msg = content.nextLine();
							String msgChiffre = chiffrerMsg(msg, destinataire); 
							
							if (msgChiffre.equals(""))
							{
								System.out.println("Probleme de chiffrement");
								break;
							} 
							else 
							{
								try {
									destUserPorteur.dechiffrerMsg("", msgChiffre, destUser, user.getNomUtilisateur());
								} catch (CertificatIntrouvable e) {
									e.printStackTrace();
								}
							}
							
						} while (!msg.equals("FIN_MSG"));
						choix = 0 ;
						break;
						
					case 3 : 
						do {
							System.out.println("Entrez votre message (mode sign�) :");
							Certificat certSign = user.demanderCertificat("signature");
							msg = content.nextLine();
							
							messageAenvoyer = new Message(false, certSign.signature, msg, user.getNomUtilisateur());
							destUser.transfererMessageSign(messageAenvoyer, (short)user.hashMethod(msg, certSign.hash), certSign);
						} while (!msg.equals("FIN_MSG"));
						break;
					
					case 4 : 
						do {
							System.out.println("Entrez votre message (mode sign� et chiffr�) :");
							Certificat certSign = user.demanderCertificat("signature");
							msg = content.nextLine();
							
							String msgChiffre = chiffrerMsg(msg, destinataire); 
							
							if (msgChiffre.equals(""))
							{
								System.out.println("Probleme de chiffrement");
								break;
							} 
							else 
							{
								destUserPorteur.dechiffrerMsgSign(msgChiffre, destUser, expediteur, user.getNomUtilisateur(), (short)user.hashMethod(msgChiffre, certSign.hash), certSign);
							}
							
						} while (!msg.equals("FIN_MSG"));
						choix = 0 ;
						break;
					default:
						break;
				}
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NotFound e) {
				e.printStackTrace();
			} catch (CannotProceed e) {
				e.printStackTrace();
			} catch (InvalidName e) {
				e.printStackTrace();
			} catch (messageChiffre e) {
				e.printStackTrace();
			}
			
				
		} while (choix < 1 || choix > 4);
	
	}

	private String chiffrerMsg(String msg, String destinataire) {
		org.omg.CosNaming.NameComponent[] nameToFindDest = new org.omg.CosNaming.NameComponent[1];
		nameToFindDest[0] = new org.omg.CosNaming.NameComponent(destinataire+".Porteur", "");
		
		// Recherche aupres du naming service
		org.omg.CORBA.Object objCDest;
		try {
			objCDest = nameRoot.resolve(nameToFindDest);
			Porteur porteurDest = PorteurHelper.narrow(objCDest);
						
			if(porteurDest.listCertificat().equals("")) 
			{
				System.out.println("Votre destinataire ne dispose pas de cl� publique.");
				return "";
			} else {

				String parts[] = porteurDest.listCertificat().split("\\|");

					Certificat certPorteur = porteurDest.demanderCertificat(parts[0]);
					
					if (user.verifCertificat("chiffrement", certPorteur))
					{
						return certPorteur.publicKey + "*" + msg;
					}

			}
				
		} catch (NotFound | CannotProceed | InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		return "";
	}

	public UtilisateurImpl getUser() {
		return user;
	}

	public void setUser(UtilisateurImpl user) {
		this.user = user;
	}

	public org.omg.CORBA.ORB getOrb() {
		return orb;
	}

	public void setOrb(org.omg.CORBA.ORB orb) {
		this.orb = orb;
	}

	public org.omg.CosNaming.NamingContext getNameRoot() {
		return nameRoot;
	}

	public void setNameRoot(org.omg.CosNaming.NamingContext nameRoot) {
		this.nameRoot = nameRoot;
	}
	
	
}
