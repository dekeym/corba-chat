package communications;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantAlreadyActive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import Implementations.PorteurImpl;
import Implementations.UtilisateurImpl;
import MessagerieSecurisee.AV;
import MessagerieSecurisee.AVHelper;
import MessagerieSecurisee.Porteur;
import MessagerieSecurisee.PorteurHelper;

public class TalkServer implements Runnable {
	private String id;
	private org.omg.CORBA.ORB orb;
	private org.omg.CosNaming.NamingContext nameRoot;
	
	public TalkServer(String id, ORB orb, NamingContext nameRoot) {
		super();
		this.id = id;
		this.orb = orb;
		this.nameRoot = nameRoot;
	}
	
	public void run() {
		try {

	        //String IORServant = orb.object_to_string(rootPOA.servant_to_reference(monTalk));
       	        
	        // Lancement de l'ORB et mise en attente de requete
	        //**************************************************
	        orb.run();
	    }
		catch (Exception e) {
			e.printStackTrace();
		}
	} // main
	
	public void enregistrement() {
        // Gestion du POA
        //****************
        // Recuperation du POA
        POA rootPOA;
		try {
			rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
			
			 // Creation du servant
	        //*********************
	        UtilisateurImpl monTalk = new UtilisateurImpl();
	        String idPorteur = id+".Porteur";
	        PorteurImpl monPorteur = new PorteurImpl(idPorteur);

	        // Activer le servant au sein du POA et recuperer son ID
	        byte[] monTalkId = rootPOA.activate_object(monTalk);
	        byte[] monPorteurId = rootPOA.activate_object(monPorteur);

	        // Activer le POA manager
	        rootPOA.the_POAManager().activate();


	        // Enregistrement dans le service de nommage
	        //*******************************************
	        // Construction du nom a enregistrer
	        org.omg.CosNaming.NameComponent[] nameToRegister = new org.omg.CosNaming.NameComponent[1];
	        nameToRegister[0] = new org.omg.CosNaming.NameComponent(id,"");
	        org.omg.CosNaming.NameComponent[] nameToRegisterPorteur = new org.omg.CosNaming.NameComponent[1];
	        nameToRegisterPorteur[0] = new org.omg.CosNaming.NameComponent(idPorteur,"");

	        // Enregistrement de l'objet CORBA dans le service de noms
	        nameRoot.rebind(nameToRegister,rootPOA.servant_to_reference(monTalk));
	        nameRoot.rebind(nameToRegisterPorteur,rootPOA.servant_to_reference(monPorteur));
	        System.out.println("==> Nom '"+ id + "' est enregistre dans le service de noms.");
	        System.out.println("==> Nom '"+ idPorteur + "' est enregistre dans le service de noms.");
		} catch (InvalidName | ServantAlreadyActive | WrongPolicy | AdapterInactive | NotFound | CannotProceed | org.omg.CosNaming.NamingContextPackage.InvalidName | ServantNotActive e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

       

	}
}
