package communications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantAlreadyActive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import Implementations.ACImpl;
import MessagerieSecurisee.AC;
import MessagerieSecurisee.ACHelper;
import MessagerieSecurisee.AE;
import MessagerieSecurisee.AEHelper;
import MessagerieSecurisee.AV;
import MessagerieSecurisee.AVHelper;

public class MainAC {
	public static void main(String[] args) { 
		BufferedReader entreeClavier = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Entrez le nom de l'AC ?");
		
		try {
			String nomAC = entreeClavier.readLine();
			
			// Intialisation de l'orb
			org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);
			
			// Recuperation du naming service
			NamingContext nameRoot=org.omg.CosNaming.NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));
			
			// Recuperation du POA
	        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
	        
	        // RECUPERATION AE ET AV
	        System.out.println("Entrez le nom de l'AV ?");
			String nomAV = entreeClavier.readLine();
			
			org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
			nameToFind[0] = new org.omg.CosNaming.NameComponent(nomAV, "");
			
			// Recherche aupres du naming service
			org.omg.CORBA.Object objC = nameRoot.resolve(nameToFind);

			// Transtypage de l'objet CORBA au type AV
			AV monAV = AVHelper.narrow(objC);
			
			System.out.println("Entrez le nom de l'AE ?");
			String nomAE = entreeClavier.readLine();
			
			nameToFind[0] = new org.omg.CosNaming.NameComponent(nomAE, "");
			
			objC = nameRoot.resolve(nameToFind);
			
			AE monAE = AEHelper.narrow(objC);
		
			System.out.println("L'AC " + nomAC +" est-il racine ? (oui | non)");
			String choix = entreeClavier.readLine();
			ACImpl AcServant;
			String acToFind;
			
			if (choix.equals("oui")) 
			{
				// Creation du servant
		        //*********************
		        AcServant = new ACImpl(nomAC, null, monAE, monAV);
		        acToFind = nomAC;
			} 
			else 
			{
				System.out.println("Quel est le nom de la m�re de l'AC " + nomAC +"?");
				String nomACMere = entreeClavier.readLine();
				
				nameToFind[0] = new org.omg.CosNaming.NameComponent(nomACMere, "");
				
				objC = nameRoot.resolve(nameToFind);
				
				AC monACMere = ACHelper.narrow(objC);
								
				// Creation du servant
		        //*********************
		        AcServant = new ACImpl(nomAC, monACMere, monAE, monAV);
		        
		        AcServant.setMonAC(monACMere);
		        
		        acToFind = nomACMere;
			}
			
			AcServant.setMonAV(monAV);
			
	        // Activer le servant au sein du POA et recuperer son ID
	        byte[] AcId = rootPOA.activate_object(AcServant);

	        // Activer le POA manager
	        rootPOA.the_POAManager().activate();


	        // Enregistrement dans le service de nommage
	        //*******************************************
	        // Construction du nom a enregistrer
	        org.omg.CosNaming.NameComponent[] nameToRegister = new org.omg.CosNaming.NameComponent[1];
	        nameToRegister[0] = new org.omg.CosNaming.NameComponent(nomAC,"");

	        // Enregistrement de l'objet CORBA dans le service de noms
	        nameRoot.rebind(nameToRegister,rootPOA.servant_to_reference(AcServant));
	        System.out.println("==> Nom '"+ nomAC + "' est enregistre dans le service de noms.");

	        String IORServant = orb.object_to_string(rootPOA.servant_to_reference(AcServant));
	        
	        org.omg.CosNaming.NameComponent[] nameToFindac = new org.omg.CosNaming.NameComponent[1];
			nameToFindac[0] = new org.omg.CosNaming.NameComponent(acToFind, "");
			
			// Recherche aupres du naming service
			org.omg.CORBA.Object objCac = nameRoot.resolve(nameToFindac);

			// Transtypage de l'objet CORBA au type AV
			AC monAC = ACHelper.narrow(objCac);
	        
	        AcServant.setMonAC(monAC);
	        AcServant.certificatAC().ACreferant = monAC;
	        
	        orb.run();
	            
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServantNotActive e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WrongPolicy e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CannotProceed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AdapterInactive e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServantAlreadyActive e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
