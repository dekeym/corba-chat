package Implementations;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import MessagerieSecurisee.Certificat;
import MessagerieSecurisee.CertificatIntrouvable;
import MessagerieSecurisee.ListUsages;
import MessagerieSecurisee.Message;
import MessagerieSecurisee.Utilisateur;
import MessagerieSecurisee.messageChiffre;

public class PorteurImpl extends MessagerieSecurisee.PorteurPOA {
	
	private Certificat cert;
	private String nomPorteur;
	private HashMap<String, Certificat> tableCertificats;
	private String privateKey;
	
	public PorteurImpl(String nomPorteur) {
		super();
		this.nomPorteur = nomPorteur;
		this.tableCertificats = new HashMap<String, Certificat>();
	}

	@Override
	public void dechiffrerMsg(String sign, String msgChiffre, Utilisateur user, String expediteur) throws CertificatIntrouvable  {
		String msgDechiffre;
		String parts[] = this.listCertificat().split("\\|");


		Certificat certPorteur = this.demanderCertificat(parts[0]);

		String partsMsg[] = msgChiffre.split("\\*");

		if (partsMsg[0].equals(certPorteur.publicKey))
		{
			msgDechiffre = partsMsg[1];
		} else {
			msgDechiffre = "Message re�u non d�chiffrable";
		}
		
		transfererMsgUtilisateur(sign, msgDechiffre, user, expediteur);
	}

	@Override
	public void signerMsg(Message msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void transfererMessage(Message msg) throws messageChiffre {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Certificat demanderCertificat(String usage) {
		return this.tableCertificats.get(usage);
	}

	@Override
	public Certificat getCertificatUtilisateur(String identifiantCertificat) {
		return this.tableCertificats.get(identifiantCertificat);
	}
	
	public HashMap<String, Certificat> getCertificatUtilisateur() {
		return this.tableCertificats;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	@Override
	public void ajouterCertificat(Certificat cert, ListUsages usage) {
		this.tableCertificats.put(this.nomPorteur+"."+usage, cert);	
	}

	@Override
	public String listCertificat() {
		String listCertificat="";
		
		Set cles = this.tableCertificats.keySet();
		Iterator it = cles.iterator();
		while (it.hasNext()){
		   Object cle = it.next(); 
		   listCertificat += cle.toString()+"|";
		}
				
		return listCertificat;
	}

	@Override
	public void suprimerCertificat(String cert) {
		this.tableCertificats.remove(cert);
	}

	@Override
	public void transfererMessageSign(Message msg, short hash, Certificat cert)
			throws messageChiffre {
		
	}


	@Override
	public void transfererMsgUtilisateur(String sign, String msgDech, Utilisateur user, String expediteur) {
		Message messageAenvoyer = new Message(true, sign, msgDech, expediteur);
		try {
			user.transfererMessage(messageAenvoyer);
		} catch (messageChiffre e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void dechiffrerMsgSign(String msgChiffre, Utilisateur user, Utilisateur expediteurUser, String expediteur, short hash, Certificat cert) {

			if (expediteurUser.verifCertificat("signature", cert))
			{
				if (cert.hash * msgChiffre.length() == hash)
				{
					try {
						this.dechiffrerMsg(cert.signature, msgChiffre, user, expediteur);
					} catch (CertificatIntrouvable e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					System.out.println("Usurpation d'identit�.");
				}
			} else {
				System.out.println("Certificat incorrecte.");
			}

	}

	@Override
	public boolean verifCertificat(String usage, Certificat cert) {
		return false;
	}
		
}
