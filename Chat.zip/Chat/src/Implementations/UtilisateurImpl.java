package Implementations;

import java.util.Scanner;

import MessagerieSecurisee.AE;
import MessagerieSecurisee.Certificat;
import MessagerieSecurisee.CertificatDejaCree;
import MessagerieSecurisee.CertificatIntrouvable;
import MessagerieSecurisee.Identite;
import MessagerieSecurisee.ListUsages;
import MessagerieSecurisee.Message;
import MessagerieSecurisee.Porteur;

public class UtilisateurImpl extends MessagerieSecurisee.UtilisateurPOA {

	private Porteur monPorteur;
	private String nomUtilisateur;
	private AE AEReferant;
	private String signatureUtilisateur;
	
	public UtilisateurImpl() {
		this.monPorteur = null;
	}
		
	public UtilisateurImpl(String nomUtilisateur){
		this.nomUtilisateur = nomUtilisateur;
		this.monPorteur = null;
		this.signatureUtilisateur = nomUtilisateur+".signature";
	}
	
	public Certificat demanderCertificat(String usage){
		return this.monPorteur.getCertificatUtilisateur(this.getNomUtilisateur()+".Porteur."+usage);
	}

	public void transfererMessageSign(Message msg, short hash, Certificat cert)
	{
		if (!msg.signature.equals("") && !msg.chiffre) {	
			if (this.verifCertificat("signature", cert))
			{
				if (cert.hash * msg.message.length() == hash)
				{
					// MESSAGE SIGNE
					System.out.println(msg.expediteur + " : " + msg.message);				
					System.out.println("Certificat Valide.");
				} else {
					System.out.println("Usurpation d'identit�.");
				}
			} else {
				System.out.println("Certificat incorrecte.");
			}
			
		}
	}
	public void transfererMessage(Message msg)
	{

		if (msg.chiffre && msg.signature.equals("")) 
		{
			System.out.println("R�ception message chiffr� :");
			// MESSAGE CHIFFRE		
			System.out.println(msg.expediteur + " : " + msg.message);
					
		} else if (!msg.signature.equals("") && msg.chiffre) {
			
			System.out.println("R�ception message chiffr� & sign� :");
			// MESSAGE CHIFFRE & SIGNE
			System.out.println(msg.expediteur + " : " + msg.message);			
			
		} else {
			System.out.println(msg.expediteur + " : " + msg.message);
		}
		
	}
	
	public void creationCertificat(Identite userIdentity){
		int str;
		Certificat cert;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("---------------------------------------------");
		System.out.println("Quel type de certificat souhaitez-vous ?");
		System.out.println("---------------------------------------------");
		System.out.println("Choix 1 : Certificat Signature");
		System.out.println("Choix 2 : Certificat Chiffrement");
		System.out.println("---------------------------------------------");
		
		str = sc.nextInt();
		
		try {
			switch (str) {
				case 1 : 

					cert = AEReferant.creationDeCertificat(userIdentity, ListUsages.signature, "CP"+userIdentity.nomUtilisateur);
					if(cert != null) 
					{
						// Ajout du certificat dans la liste du porteur
						getMonPorteur().ajouterCertificat(cert, ListUsages.signature);

					}
					break;
					
				case 2 : 

					cert = AEReferant.creationDeCertificat(userIdentity, ListUsages.chiffrement, "CP"+userIdentity.nomUtilisateur);
					if(cert != null) 
					{
						// Ajout du certificat dans la liste du porteur
						getMonPorteur().ajouterCertificat(cert, ListUsages.chiffrement);
					}
					break;
					
			}
			
		} catch (CertificatDejaCree e) {
			e.printStackTrace();
		}
	}
	
	public void revocationCertificat(Identite userIdentity)
	{
		String listCert = getMonPorteur().listCertificat();
		int str;
		Scanner sc = new Scanner(System.in);
		String parts[] = listCert.split("\\|");
		int i = 0;

		for (String st : parts) {
			System.out.println("Choix " + i + " : r�voquer " + st);
			i++;
		}

		System.out.println("Entrer votre choix : ");
		str = sc.nextInt();

		try {
			AEReferant.demandeDeRevocation(userIdentity, parts[str]);
			getMonPorteur().suprimerCertificat(parts[str]);
		
		} catch (CertificatIntrouvable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void suspensionCertificat(Identite userIdentity)
	{
		String listCert = getMonPorteur().listCertificat();
		int str;
		Scanner sc = new Scanner(System.in);
		String parts[] = listCert.split("\\|");
		int i = 0;

		for (String st : parts) {
			System.out.println("Choix " + i + " : suspendre " + st);
			i++;
		}

		System.out.println("Entrer votre choix : ");
		str = sc.nextInt();

		try {
			AEReferant.demandeDeSuspension(userIdentity, parts[str]);
		
		} catch (CertificatIntrouvable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean verifCertificat(String usage, Certificat cert)
	{		
		try {
			boolean rtn = cert.ACreferant.demandeValidationCertificat(cert);
			return rtn;
		} catch (CertificatIntrouvable e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public String getNomUtilisateur() {
		return nomUtilisateur;
	}

	public void setNomUtilisateur(String nomUtilisateur) {
		this.nomUtilisateur = nomUtilisateur;
	}

	public Porteur getMonPorteur() {
		return this.monPorteur;
	}

	public AE getAEReferant() {
		return AEReferant;
	}

	public void setAEReferant(AE aEReferant) {
		AEReferant = aEReferant;
	}

	public void setMonPorteur(Porteur monPorteur) {
		this.monPorteur = monPorteur;
	}

	public String getSignatureUtilisateur() {
		return signatureUtilisateur;
	}

	public void setSignatureUtilisateur(String signatureUtilisateur) {
		this.signatureUtilisateur = signatureUtilisateur;
	}
	
	public int hashMethod (String msg, short hash)
	{
		return msg.length() * hash;
	}
	
}
