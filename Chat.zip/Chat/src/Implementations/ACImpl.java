package Implementations;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;

import MessagerieSecurisee.AC;
import MessagerieSecurisee.AE;
import MessagerieSecurisee.AV;
import MessagerieSecurisee.Certificat;
import MessagerieSecurisee.CertificatDejaCree;
import MessagerieSecurisee.CertificatIntrouvable;
import MessagerieSecurisee.Date;
import MessagerieSecurisee.Identite;
import MessagerieSecurisee.ListUsages;

public class ACImpl extends MessagerieSecurisee.ACPOA {

	private String identifiantAC;
	private Certificat certificatAC;
	private HashMap<String, Certificat> listLCR;
	private HashMap<String, Certificat> listLCS;
	private HashMap<String, Certificat> listLC;
	private AC monAC;
	private AV monAV;
	
	public ACImpl (String identifiantAC, AC acMere, AE aeMere, AV avMere)
	{
		this.listLCR = new HashMap<String, Certificat>();
		this.listLCS = new HashMap<String, Certificat>();
		this.listLC = new HashMap<String, Certificat>();
		
		Calendar calendar = new GregorianCalendar();
		java.util.Date trialTime = new java.util.Date();
		calendar.setTime(trialTime);
		
		Date debut = new Date((short) calendar.get(Calendar.DAY_OF_MONTH), (short) calendar.get(Calendar.MONTH), (short) calendar.get(Calendar.YEAR));
		Date fin = new Date((short) calendar.get(Calendar.DAY_OF_MONTH), (short) calendar.get(Calendar.MONTH), (short) (calendar.get(Calendar.YEAR)+1));
		
		//Certificat autosign�
		if(acMere == null)
		{
			certificatAC = new Certificat(identifiantAC, identifiantAC+"cp", null, identifiantAC+"sig", debut, fin, ListUsages.signature, null, (short)identifiantAC.length());
			this.listLC.put(identifiantAC, certificatAC);
		} else {
			certificatAC = new Certificat(identifiantAC, identifiantAC+"cp", acMere, identifiantAC+"sig", debut, fin, ListUsages.signature, null, (short)identifiantAC.length());
			this.listLC.put(identifiantAC, certificatAC);
		}
		
		this.identifiantAC = identifiantAC;
	}
	
	public AC getMonAC() {
		return monAC;
	}

	public void setMonAC(AC monAC) {
		this.monAC = monAC;
	}
	
	public AV getMonAV() {
		return monAV;
	}

	public void setMonAV(AV monAV) {
		this.monAV = monAV;
	}

	@Override
	public String identifiantAC() {
		// TODO Auto-generated method stub
		return this.identifiantAC;
	}

	@Override
	public Certificat certificatAC() {
		// TODO Auto-generated method stub
		return this.certificatAC;
	}

	@Override
	public Certificat creationDeCertificat(String nomUtilisateur, ListUsages usages, String CP, AC Aclevel) throws CertificatDejaCree {
		
		if (this.listLC.containsKey(nomUtilisateur+".Porteur."+usages))
		{
			throw new CertificatDejaCree("Le certificat de " + nomUtilisateur+".Porteur."+usages + " existe d�j�.");
		}
		
		Calendar calendar = new GregorianCalendar();
		java.util.Date trialTime = new java.util.Date();
		calendar.setTime(trialTime);
		
		Date debut = new Date((short) calendar.get(Calendar.DAY_OF_MONTH), (short) calendar.get(Calendar.MONTH), (short) calendar.get(Calendar.YEAR));
		Date fin = new Date((short) calendar.get(Calendar.DAY_OF_MONTH), (short) calendar.get(Calendar.MONTH), (short) (calendar.get(Calendar.YEAR)+1));
		
		Certificat cert = new Certificat(nomUtilisateur+".Porteur."+usages, CP, Aclevel, identifiantAC+"sig", debut, fin, usages, monAV, (short)nomUtilisateur.length());

		this.listLC.put(nomUtilisateur+".Porteur."+usages, cert);
		
		return cert;
	}

	@Override
	// 2 exceptions !!!! introuvable ou dans LCR
	public void demandeDeSuspension(String identifiantCertificatUtilisateur)
			throws CertificatIntrouvable {

		if (this.listLC.containsKey(identifiantCertificatUtilisateur))
		{
			this.listLCS.put(identifiantCertificatUtilisateur, this.listLC.get(identifiantCertificatUtilisateur));
			this.listLC.remove(identifiantCertificatUtilisateur);
		} else if (this.listLCS.containsKey(identifiantCertificatUtilisateur))
		{
			this.listLC.put(identifiantCertificatUtilisateur, this.listLCS.get(identifiantCertificatUtilisateur));
			this.listLCS.remove(identifiantCertificatUtilisateur);
		} else  {
			throw new CertificatIntrouvable("Le certificat "+ identifiantCertificatUtilisateur +" est introuvable ou r�voqu�.");
		}
		
	}

	@Override
	public void demandeDeRevocation(String identifiantCertificatUtilisateur)
			throws CertificatIntrouvable {

		if (this.listLC.containsKey(identifiantCertificatUtilisateur))
		{
			this.listLCR.put(identifiantCertificatUtilisateur, this.listLC.get(identifiantCertificatUtilisateur));
			this.listLC.remove(identifiantCertificatUtilisateur);
		} else if (this.listLCS.containsKey(identifiantCertificatUtilisateur))
		{
			this.listLCR.put(identifiantCertificatUtilisateur, this.listLCS.get(identifiantCertificatUtilisateur));
			this.listLCS.remove(identifiantCertificatUtilisateur);
		} else  {
			throw new CertificatIntrouvable("Le certificat "+ identifiantCertificatUtilisateur +" est introuvable ou r�voqu�.");
		}
		
	}

	@Override
	public boolean demandeValidationCertificat(Certificat certificatUtilisateur) throws CertificatIntrouvable {
				
		if (certificatUtilisateur.signature.equals(certificatUtilisateur.ACreferant.identifiantAC()+"sig")) 
		{
			AC ACRef;
			do {
				ACRef = getMonAC();
				
			} while(!ACRef.certificatAC().signature.equals(ACRef.identifiantAC()+"sig"));
			
			return true;
		}
			
		return false;
	}

	@Override
	public boolean demandeVerificationCertificat(Certificat certificatUtilisateur) throws CertificatIntrouvable {
		
		Calendar rightNow = Calendar.getInstance();
		int year = rightNow.YEAR;
		int month = rightNow.MONTH;
		int day = rightNow.DAY_OF_MONTH;
		
		if(listLC.containsKey(certificatUtilisateur.identifiantCertificat))
		{
			if (certificatUtilisateur.dateFin.annee >= year && certificatUtilisateur.dateFin.mois >= month && certificatUtilisateur.dateFin.jour > day)
			{
				return true;
			} else {
				return false;
			}
		} 
		else
		{
			return false;
		} 

	}

}
