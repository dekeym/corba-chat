package Implementations;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import MessagerieSecurisee.AC;
import MessagerieSecurisee.Certificat;
import MessagerieSecurisee.CertificatDejaCree;
import MessagerieSecurisee.CertificatIntrouvable;
import MessagerieSecurisee.Identite;
import MessagerieSecurisee.ListUsages;

public class AEImpl extends MessagerieSecurisee.AEPOA {
	private String nomAE;
	private Properties pt;
	private AC monAc;
	
	public AEImpl(String nomAE) {
		this.nomAE = nomAE;
		
		// Read properties file.
		pt = new Properties();
		try {
			FileInputStream input = new FileInputStream("./src/ressources/account"+nomAE+".properties");
			pt.load(input);
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}
	
	@Override
	public Certificat creationDeCertificat(Identite identiteUtilisateur, ListUsages usages, String CP) throws CertificatDejaCree {
		String result = "";
		Certificat cert=null;
		Enumeration enuKeys = getPt().keys();
		boolean found = false;
		
		while (enuKeys.hasMoreElements() || found != true) 
		{
			String key = (String) enuKeys.nextElement();
			
			String str[] = getPt().getProperty(key).split(" ");
			
			if (key.equals(identiteUtilisateur.nomUtilisateur) && identiteUtilisateur.mdpUtilisateur.equals(str[0]))
			{
				if(usages.equals(ListUsages.signature))
				{
					if(str[1].equals("true"))
					{
						cert =  monAc.creationDeCertificat(identiteUtilisateur.nomUtilisateur, usages, CP, monAc);
						found = true;
			
					} else {
						result = "Demande de droit incorrecte";
						System.out.println(result);
					}
				} 
				else if(usages.equals(ListUsages.chiffrement))
				{
					if(str[2].equals("true"))
					{
						cert =  monAc.creationDeCertificat(identiteUtilisateur.nomUtilisateur, usages, CP, monAc);
						found = true;
					} else {
						result = "Demande de droit incorrecte";
						System.out.println(result);
					}
				}
				else if(usages.equals(ListUsages.revocation))
				{
					if(str[3].equals("true"))
					{
						cert =  monAc.creationDeCertificat(identiteUtilisateur.nomUtilisateur, usages, CP, monAc);
						found = true;
					} else {
						result = "Demande de droit incorrecte";
						System.out.println(result);
					}
				}
				else if(usages.equals(ListUsages.suspension))
				{
					if(str[4].equals("true"))
					{
						cert =  monAc.creationDeCertificat(identiteUtilisateur.nomUtilisateur, usages, CP, monAc);
						found = true;
					} else {
						result = "Demande de droit incorrecte";
						System.out.println(result);
					}
				}
			} 
		}
		return cert;
	}

	public AC getMonAc() {
		return monAc;
	}

	public void setMonAc(AC monAc) {
		this.monAc = monAc;
	}

	public Properties getPt() {
		return pt;
	}

	public void setPt(Properties pt) {
		this.pt = pt;
	}

	public String getNomAE() {
		return nomAE;
	}

	public void setNomAE(String nomAE) {
		this.nomAE = nomAE;
	}

	@Override
	public void demandeDeSuspension(Identite identiteUtilisateur, String identifiantCertificatUtilisateur)
			throws CertificatIntrouvable {

			Enumeration enuKeys = getPt().keys();
			boolean found = false;
			
			while (enuKeys.hasMoreElements() || found != true) 
			{
				String key = (String) enuKeys.nextElement();
				
				String str[] = getPt().getProperty(key).split(" ");
	
				if (key.equals(identiteUtilisateur.nomUtilisateur) && identiteUtilisateur.mdpUtilisateur.equals(str[0]))
				{
					found = true;
					
					if(str[4].equals("true"))
					{
						monAc.demandeDeSuspension(identifiantCertificatUtilisateur);
					} else {
						System.out.println(identiteUtilisateur.nomUtilisateur + " ne dispose pas du droit de r�vocation.");
					}
				}
			}
		
	}

	@Override
	public void demandeDeRevocation(Identite identiteUtilisateur, String identifiantCertificatUtilisateur)
			throws CertificatIntrouvable {
		
		Enumeration enuKeys = getPt().keys();
		boolean found = false;
		
		while (enuKeys.hasMoreElements() || found != true) 
		{
			String key = (String) enuKeys.nextElement();
			
			String str[] = getPt().getProperty(key).split(" ");

			if (key.equals(identiteUtilisateur.nomUtilisateur) && identiteUtilisateur.mdpUtilisateur.equals(str[0]))
			{
				found = true;
				
				if(str[3].equals("true"))
				{
					monAc.demandeDeRevocation(identifiantCertificatUtilisateur);
				} else {
					System.out.println(identiteUtilisateur.nomUtilisateur + " ne dispose pas du droit de r�vocation.");
				}
			}
		}
				
	}
	
}
