package Implementations;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import MessagerieSecurisee.AC;
import MessagerieSecurisee.Certificat;
import MessagerieSecurisee.CertificatIntrouvable;

public class AVImpl extends MessagerieSecurisee.AVPOA {
	private String nomAV;
	private AC monAC;
	
	public AC getMonAC() {
		return monAC;
	}
	
	public AVImpl(String nomAV) {
		this.nomAV = nomAV;
	}

	public void setMonAC(AC monAC) {
		this.monAC = monAC;
	}

	@Override
	public boolean demandeValidationCertificat(Certificat certificatUtilisateur)
			throws CertificatIntrouvable {
		
		return this.monAC.demandeValidationCertificat(certificatUtilisateur);
	}

	@Override
	public boolean demandeVerificationCertificat(Certificat certificatUtilisateur)
			throws CertificatIntrouvable {
		
		return this.monAC.demandeVerificationCertificat(certificatUtilisateur);
	}

}
